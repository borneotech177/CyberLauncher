# Cyber Launcher
Launcher Android bertema cyber security + toolkit network & security.

Network: INFO, PING, TRACE, DNS, PORTS, LAN, SUBNET, WHOIS, HTTP, SSL
Security: HASH, ENCODE, DECODE, PASSGEN, PASSCHK, PWNED, JWT, APPAUDIT

Gunakan tool pemindai (PORTS, LAN) hanya pada perangkat/jaringan milik sendiri atau yang ada izin tertulis.

Upload ke GitHub -> tab Actions -> Build APK -> download artifact.
