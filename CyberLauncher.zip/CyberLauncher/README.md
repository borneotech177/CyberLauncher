# Cyber Launcher
Launcher Android bertema cyber security + toolkit network, security, dan jembatan Termux.

## Perbaikan tampilan & performa launcher
- Daftar aplikasi sekarang di-cache, tidak dimuat ulang setiap balik ke Home (dulu ini
  yang bikin terasa lag/kosong). Pembaruan hanya terjadi saat ada app diinstall/dihapus.
- Ada banner otomatis kalau launcher belum jadi default, ketuk untuk memicu dialog
  resmi Android (RoleManager) buat mengaktifkannya, lebih reliable daripada lewat
  Setelan manual terutama di HP dengan skin OEM (XOS/ColorOS/dll).
- Dock dirapikan jadi 2 baris (TOOLS/SYS, lalu DIAL/CAM/WEB), ikon aplikasi dikasih
  bingkai rounded, sudut panel diperlembut.
Semua tool sekarang menutup hasilnya dengan bagian "// ANALISA OTOMATIS" berisi kesimpulan,
bukan cuma data mentah.

## Tool bawaan (tanpa Termux)
Network: INFO, PING, TRACE, DNS, PORTS, LAN, SUBNET, WHOIS, HTTP, SSL, SPEEDTEST, WIFISCAN, GEOIP, WOL, PINGLOOP
Security: WAF, SPF/DMARC, SUBS, COOKIE, SEC.TXT, CVE, HASH, ENCODE, DECODE, PASSGEN, PASSCHK, PWNED, JWT, APPAUDIT

Catatan: NETCUT (pemutus koneksi perangkat lain lewat ARP spoofing) sengaja TIDAK
dibuat karena itu serangan jaringan ke perangkat orang lain, bukan tool audit.
Untuk mengatur perangkat di jaringan sendiri, pakai fitur blokir MAC/QoS di router.

Tool web security baru:
- WAF    : deteksi CDN/WAF (Cloudflare, Sucuri, Akamai, dll) dari fingerprint header
- SPF/DMARC : audit keamanan email domain (cegah spoofing)
- SUBS   : enumerasi subdomain lewat log sertifikat publik (crt.sh), pasif, tanpa menyentuh target

## Tab TERMUX
Menjalankan perintah langsung di Termux lewat API resmi RUN_COMMAND, hasil
(stdout/stderr/exit code) ditarik balik ke launcher, plus analisa otomatis.

Syarat satu kali di sisi Termux:
1. Install Termux dari F-Droid atau rilis GitHub resmi (BUKAN Play Store).
2. Di Termux: tambahkan `allow-external-apps = true` ke
   `~/.termux/termux.properties`, lalu jalankan `termux-reload-settings`.
3. Di launcher, tab TERMUX -> status koneksi tampil otomatis, ketuk [ IZIN ]
   kalau belum ada izin RUN_COMMAND.

Preset siap pakai: SETUP, NMAP, NMAP-FULL, NIKTO, WHATWEB, DIG, TRACE, TCPDUMP, MTR, SSLSCAN, DIRB.

Gunakan tool pemindai (PORTS, LAN, NMAP, NIKTO, SUBS) hanya pada perangkat/jaringan
milik sendiri atau yang ada izin tertulis.

## Build
Upload ke GitHub -> tab Actions -> Build APK -> download artifact.
Project ini sudah pakai keystore tetap (app/cyberlauncher.keystore), jadi install
APK baru bisa langsung menimpa yang lama tanpa uninstall.
