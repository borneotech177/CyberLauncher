# Cyber Launcher
Launcher Android bertema cyber security + toolkit network, security, dan jembatan Termux.

## Tool bawaan (tanpa Termux)
Network: INFO, PING, TRACE, DNS, PORTS, LAN, SUBNET, WHOIS, HTTP, SSL
Security: HASH, ENCODE, DECODE, PASSGEN, PASSCHK, PWNED, JWT, APPAUDIT

## Tab TERMUX
Menjalankan perintah langsung di Termux lewat API resmi RUN_COMMAND, hasil
(stdout/stderr/exit code) ditarik balik ke launcher, plus analisa singkat.

Syarat satu kali di sisi Termux:
1. Install Termux dari F-Droid atau rilis GitHub resmi (BUKAN Play Store).
2. Di Termux: tambahkan `allow-external-apps = true` ke
   `~/.termux/termux.properties`, lalu jalankan `termux-reload-settings`.
3. Di launcher, tab TERMUX -> ketuk [ CEK ] lalu [ IZIN ] untuk memberi izin
   RUN_COMMAND (dialog izin Android standar).

Preset siap pakai: SETUP (install nmap/nikto/whatweb), NMAP, NMAP-FULL,
NIKTO, WHATWEB, DIG, TRACE, TCPDUMP. Kolom perintah juga bisa diisi manual.

Gunakan tool pemindai (PORTS, LAN, NMAP, NIKTO) hanya pada perangkat/jaringan
milik sendiri atau yang ada izin tertulis.

## Build
Upload ke GitHub -> tab Actions -> Build APK -> download artifact.
Versi 2.0 ini perlu uninstall dulu sebelum install (tanda tangan build beda
dari sebelumnya); setelah ini sebaiknya pasang keystore tetap supaya update
berikutnya tidak perlu uninstall lagi.
