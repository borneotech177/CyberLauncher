# Cyber Launcher
Launcher Android bertema cyber security + toolkit network, security, dan jembatan Termux.

## Perbaikan tampilan & performa launcher
- Daftar aplikasi sekarang di-cache, tidak dimuat ulang setiap balik ke Home (dulu ini
  yang bikin terasa lag/kosong). Pembaruan hanya terjadi saat ada app diinstall/dihapus.
- Ada banner otomatis kalau launcher belum jadi default, ketuk untuk memicu dialog
  resmi Android (RoleManager) buat mengaktifkannya, lebih reliable daripada lewat
  Setelan manual terutama di HP dengan skin OEM (XOS/ColorOS/dll).
- Dock dirapikan jadi 2 baris (TOOLS/SYS, lalu DIAL/CAM/WEB), ikon aplikasi dikasih
  bingkai rounded, sudut panel diperlembut.
Semua tool sekarang menutup hasilnya dengan bagian "// ANALISA OTOMATIS" berisi kesimpulan,
bukan cuma data mentah.

## Tool bawaan (tanpa Termux)
Network: INFO, PING, TRACE, DNS, PORTS, LAN, SUBNET, WHOIS, HTTP, SSL, SPEEDTEST, WIFISCAN, WIFIINFO, WIFIMON, GEOIP, WOL, PINGLOOP
Security: WAF, SPF/DMARC, SUBS, COOKIE, SEC.TXT, CVE, HASH, ENCODE, DECODE, PASSGEN, PASSCHK, PWNED, JWT, APPAUDIT

Catatan: NETCUT (pemutus koneksi perangkat lain lewat ARP spoofing) sengaja TIDAK
dibuat karena itu serangan jaringan ke perangkat orang lain, bukan tool audit.
Untuk mengatur perangkat di jaringan sendiri, pakai fitur blokir MAC/QoS di router.

Tool web security baru:
- WAF    : deteksi CDN/WAF (Cloudflare, Sucuri, Akamai, dll) dari fingerprint header
- SPF/DMARC : audit keamanan email domain (cegah spoofing)
- SUBS   : enumerasi subdomain lewat log sertifikat publik (crt.sh), pasif, tanpa menyentuh target

## Tab TERMUX
Menjalankan perintah langsung di Termux lewat API resmi RUN_COMMAND, hasil
(stdout/stderr/exit code) ditarik balik ke launcher, plus analisa otomatis.

Syarat satu kali di sisi Termux (tab TERMUX -> ketuk [ CEK ] untuk panduannya):
1. Install Termux dari F-Droid atau rilis GitHub resmi (BUKAN Play Store).
2. Izin RUN_COMMAND (tombol [ 2.IZIN ] di launcher).
3. Izin "Tampil di atas aplikasi lain" untuk Termux (tombol [ 3.OVERLAY ]).
4. Baterai Termux disetel "Tanpa batasan" (tombol [ 4.BATERAI ] -> buka halaman
   info app Termux -> Baterai -> Tanpa batasan).
5. Di dalam Termux, jalankan sekali:
   echo 'allow-external-apps=true' >> ~/.termux/termux.properties && termux-reload-settings

Langkah 3 dan 4 tidak bisa dicek otomatis oleh Android, jadi tetap wajib dicek manual
meski langkah 1-2 sudah OK. Tanpa langkah 3 & 4, perintah dari launcher sering gagal
diam-diam (output kosong) terutama kalau Termux belum pernah dibuka sejak HP nyala.

Preset siap pakai: SETUP, NMAP, NMAP-FULL, NIKTO, WHATWEB, DIG, TRACE, TCPDUMP, MTR, SSLSCAN, DIRB.

Gunakan tool pemindai (PORTS, LAN, NMAP, NIKTO, SUBS) hanya pada perangkat/jaringan
milik sendiri atau yang ada izin tertulis.

## Build
Upload ke GitHub -> tab Actions -> Build APK -> download artifact.
Project ini sudah pakai keystore tetap (app/cyberlauncher.keystore), jadi install
APK baru bisa langsung menimpa yang lama tanpa uninstall.
