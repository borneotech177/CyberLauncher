package com.borneotech.cyberlauncher

import android.app.Activity
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.ConnectException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.Base64
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.math.ln
import kotlin.math.pow

/** Kumpulan tool network & security. Semua jalan lokal di HP. */
class ToolBox(private val ctx: Context, val out: (String) -> Unit) {

    @Volatile var cancelled = false
    @Volatile private var proc: Process? = null
    @Volatile private var pool: ExecutorService? = null

    fun stop() {
        cancelled = true
        proc?.destroy()
        pool?.shutdownNow()
    }

    // ---------- helper ----------
    private fun validHost(h: String) =
        h.isNotBlank() && !h.startsWith("-") && Regex("""^[A-Za-z0-9._:\-]+$""").matches(h)

    private fun hex(b: ByteArray) = b.joinToString("") { "%02x".format(it) }

    private fun httpGet(u: String): String {
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "CyberLauncher/1.0")
        return try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private val services = mapOf(
        21 to "ftp", 22 to "ssh", 23 to "telnet", 25 to "smtp", 53 to "dns",
        80 to "http", 110 to "pop3", 139 to "netbios", 143 to "imap", 443 to "https",
        445 to "smb", 3306 to "mysql", 3389 to "rdp", 5432 to "postgres",
        5555 to "adb", 8080 to "http-alt", 8443 to "https-alt"
    )

    private fun runPing(args: Array<String>): String {
        val p = ProcessBuilder(*args).redirectErrorStream(true).start()
        proc = p
        val txt = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return txt
    }

    // ---------- NETWORK ----------
    fun netInfo() {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val net = cm.activeNetwork
        if (net == null) {
            out("[!] Tidak ada koneksi aktif\n"); return
        }
        val lp = cm.getLinkProperties(net)
        val caps = cm.getNetworkCapabilities(net)
        val tr = when {
            caps == null -> "-"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "SELULER"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            else -> "LAIN"
        }
        out("JENIS     : $tr\n")
        out("INTERFACE : ${lp?.interfaceName}\n")
        lp?.linkAddresses?.forEach { out("IP        : ${it.address.hostAddress}/${it.prefixLength}\n") }
        lp?.routes?.filter { it.isDefaultRoute }?.forEach { out("GATEWAY   : ${it.gateway?.hostAddress}\n") }
        lp?.dnsServers?.forEach { out("DNS       : ${it.hostAddress}\n") }
        if (lp?.isPrivateDnsActive == true) out("PRIV DNS  : ${lp.privateDnsServerName ?: "auto"}\n")
        out("MTU       : ${lp?.mtu}\n")
        out("VPN       : ${if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true) "ON" else "OFF"}\n")
        if (caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true) {
            try {
                val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                @Suppress("DEPRECATION") val wi = wm.connectionInfo
                out("SSID      : ${wi.ssid}\n")
                out("SINYAL    : ${wi.rssi} dBm\n")
                out("KECEPATAN : ${wi.linkSpeed} Mbps\n")
                out("FREKUENSI : ${wi.frequency} MHz\n")
            } catch (e: Exception) { }
        }
        val pub = try { httpGet("https://api.ipify.org").trim() } catch (e: Exception) { "gagal ambil" }
        out("IP PUBLIK : $pub\n")
    }

    fun ping(host: String) {
        val h = host.trim()
        if (!validHost(h)) { out("[!] Host tidak valid\n"); return }
        try {
            val p = ProcessBuilder("/system/bin/ping", "-c", "4", "-W", "3", h)
                .redirectErrorStream(true).start()
            proc = p
            p.inputStream.bufferedReader().forEachLine { if (!cancelled) out(it + "\n") }
            p.waitFor()
        } catch (e: Exception) {
            out("[!] ${e.message}\n")
        }
    }

    fun traceroute(host: String) {
        val h = host.trim()
        if (!validHost(h)) { out("[!] Host tidak valid\n"); return }
        val fromRe = Regex("""[Ff]rom\s+(?:[^\s(]+\s+\()?([0-9a-fA-F:.]+)""")
        val timeRe = Regex("""time=([\d.]+)""")
        out("TRACE ke $h (maks 20 hop)\n\n")
        for (ttl in 1..20) {
            if (cancelled) break
            val txt = runPing(arrayOf("/system/bin/ping", "-c", "1", "-t", "$ttl", "-W", "2", h))
            val ip = fromRe.find(txt)?.groupValues?.get(1)?.trimEnd(':', '.')
            val ms = timeRe.find(txt)?.groupValues?.get(1)
            out(String.format("%2d  %-18s %s\n", ttl, ip ?: "*", if (ms != null) "$ms ms" else ""))
            if (txt.contains("bytes from")) {
                out("\n[ OK ] tujuan tercapai\n"); break
            }
        }
    }

    fun dns(host: String) {
        val h = host.trim()
        if (!validHost(h)) { out("[!] Host tidak valid\n"); return }
        val all = InetAddress.getAllByName(h)
        all.forEach {
            out("${if (it is Inet6Address) "AAAA" else "A   "}  ${it.hostAddress}\n")
        }
        out("PTR   ${all[0].canonicalHostName}\n")
    }

    private fun parsePorts(spec: String?): List<Int> {
        if (spec == null) return services.keys.sorted()
        return try {
            if (spec.contains("-")) {
                val r = spec.split("-").map { it.toInt() }
                val a = r[0]
                val b = r[1]
                if (a < 1 || b > 65535 || a > b || b - a > 10000) emptyList() else (a..b).toList()
            } else {
                spec.split(",").map { it.trim().toInt() }.filter { it in 1..65535 }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun portScan(input: String) {
        val parts = input.trim().split(Regex("\\s+"))
        val host = parts[0]
        if (!validHost(host)) { out("[!] Host tidak valid\n"); return }
        val ports = parsePorts(parts.getOrNull(1))
        if (ports.isEmpty()) {
            out("[!] Format port salah. Contoh: 192.168.1.1 1-1024\n"); return
        }
        val addr = try { InetAddress.getByName(host) } catch (e: Exception) {
            out("[!] DNS gagal\n"); return
        }
        out("TARGET ${addr.hostAddress} | ${ports.size} port\n")
        out("(Pindai hanya perangkat milik sendiri / ada izin)\n\n")
        val p = Executors.newFixedThreadPool(64)
        pool = p
        val open = java.util.Collections.synchronizedList(mutableListOf<Int>())
        for (port in ports) {
            p.execute {
                if (cancelled) return@execute
                try {
                    Socket().use { s -> s.connect(InetSocketAddress(addr, port), 700) }
                    open.add(port)
                    out("[OPEN] $port  ${services[port] ?: ""}\n")
                } catch (e: Exception) { }
            }
        }
        p.shutdown()
        p.awaitTermination(10, TimeUnit.MINUTES)
        out("\nSelesai. ${open.size} port terbuka.\n")
        val riskMap = mapOf(
            21 to "FTP tanpa enkripsi, password bisa disadap",
            23 to "Telnet tanpa enkripsi, sangat tidak aman",
            139 to "NetBIOS, rawan diakses dari luar",
            445 to "SMB, sering jadi target ransomware kalau terbuka ke internet",
            3306 to "MySQL, sebaiknya tidak terbuka ke internet publik",
            3389 to "RDP, target umum serangan brute-force",
            5432 to "PostgreSQL, sebaiknya tidak terbuka ke internet publik",
            5555 to "ADB debug, kalau ini bukan HP sendiri ini celah serius"
        )
        val risky = open.filter { riskMap.containsKey(it) }
        out("\n// ANALISA OTOMATIS\n")
        if (risky.isEmpty()) out("Tidak ada port berisiko tinggi yang umum ditemukan dari hasil ini.\n")
        else {
            out("[!] ${risky.size} port berisiko ditemukan:\n")
            risky.forEach { out("  • $it: ${riskMap[it]}\n") }
            out("-> Tutup port ini di firewall kalau tidak benar-benar perlu diakses dari luar.\n")
        }
    }

    fun lanScan() {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val lp = cm.getLinkProperties(cm.activeNetwork)
        val la = lp?.linkAddresses?.firstOrNull { it.address is Inet4Address }
        if (la == null) {
            out("[!] Tidak ada IPv4 aktif (sambung ke WiFi dulu)\n"); return
        }
        val b = la.address.address
        val me = la.address.hostAddress
        val o0 = b[0].toInt() and 255
        val o1 = b[1].toInt() and 255
        val o2 = b[2].toInt() and 255
        out("SCAN $o0.$o1.$o2.0/24 (hanya jaringan sendiri)\n\n")
        val probe = intArrayOf(80, 443, 22, 445, 8080, 53)
        val p = Executors.newFixedThreadPool(48)
        pool = p
        val found = AtomicInteger(0)
        for (i in 1..254) {
            p.execute {
                if (cancelled) return@execute
                val a = InetAddress.getByAddress(byteArrayOf(b[0], b[1], b[2], i.toByte()))
                var up = try { a.isReachable(400) } catch (e: Exception) { false }
                if (!up) {
                    for (port in probe) {
                        try {
                            Socket().use { s -> s.connect(InetSocketAddress(a, port), 250) }
                            up = true
                            break
                        } catch (e: ConnectException) {
                            if (e.message?.contains("refused", true) == true) { up = true; break }
                        } catch (e: Exception) { }
                    }
                }
                if (up) {
                    found.incrementAndGet()
                    val ip = a.hostAddress
                    val name = try { a.canonicalHostName } catch (e: Exception) { ip }
                    val tag = if (ip == me) "  <- HP ini" else ""
                    out("[UP] $ip${if (name != ip) "  ($name)" else ""}$tag\n")
                }
            }
        }
        p.shutdown()
        p.awaitTermination(5, TimeUnit.MINUTES)
        out("\nSelesai. ${found.get()} perangkat aktif.\n")
        out("Catatan: Android 10+ memblokir pembacaan tabel ARP, jadi MAC tidak tampil.\n")
    }

    fun subnet(input: String) {
        val m = Regex("""^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})/(\d{1,2})$""").find(input.trim())
        if (m == null) { out("[!] Format: 192.168.1.10/24\n"); return }
        val o = (1..4).map { m.groupValues[it].toInt() }
        val p = m.groupValues[5].toInt()
        if (o.any { it > 255 } || p > 32) { out("[!] Nilai tidak valid\n"); return }
        val ip = (o[0].toLong() shl 24) or (o[1].toLong() shl 16) or (o[2].toLong() shl 8) or o[3].toLong()
        val full = 0xFFFFFFFFL
        val mask = if (p == 0) 0L else (full shl (32 - p)) and full
        val net = ip and mask
        val bc = net or (mask.inv() and full)
        fun s(x: Long) = "${(x shr 24) and 255}.${(x shr 16) and 255}.${(x shr 8) and 255}.${x and 255}"
        val hosts = when (p) { 32 -> 1L; 31 -> 2L; else -> (1L shl (32 - p)) - 2 }
        val first = if (p >= 31) net else net + 1
        val last = if (p >= 31) bc else bc - 1
        out("IP         : ${s(ip)}/$p\n")
        out("NETMASK    : ${s(mask)}\n")
        out("WILDCARD   : ${s(mask.inv() and full)}\n")
        out("NETWORK    : ${s(net)}\n")
        out("BROADCAST  : ${s(bc)}\n")
        out("HOST RANGE : ${s(first)} - ${s(last)}\n")
        out("JUMLAH HOST: $hosts\n")
    }

    private fun whoisQuery(server: String, q: String): String =
        Socket().use { s ->
            s.connect(InetSocketAddress(server, 43), 7000)
            s.soTimeout = 8000
            s.getOutputStream().write((q + "\r\n").toByteArray())
            s.getInputStream().bufferedReader().readText()
        }

    fun whois(q: String) {
        val d = q.trim().lowercase()
        if (!validHost(d)) { out("[!] Domain/IP tidak valid\n"); return }
        val r1 = whoisQuery("whois.iana.org", d)
        val ref = Regex("(?im)^refer:\\s*(\\S+)").find(r1)?.groupValues?.get(1)
        val res = if (ref != null) whoisQuery(ref, d) else r1
        val fields = listOf("Registrar", "Registry Expiry Date", "Expiry Date", "Creation Date", "Domain Status", "Name Server")
        val summary = fields.mapNotNull { f ->
            Regex("(?im)^\\s*$f:\\s*(.+)$").find(res)?.groupValues?.get(1)?.trim()?.let { "$f: $it" }
        }
        out("// RINGKASAN\n")
        if (summary.isEmpty()) out("(tidak terbaca otomatis, lihat data mentah di bawah)\n")
        else summary.forEach { out("$it\n") }
        out("\n// DATA MENTAH\n")
        out(res.take(3500) + "\n")
    }

    /** Deteksi WAF/CDN di depan sebuah situs dari fingerprint header, tanpa payload berbahaya. */
    fun wafDetect(input: String) {
        val t = input.trim()
        if (t.isEmpty()) { out("[!] Isi domain/URL\n"); return }
        val u = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (CyberLauncher)")
        val headers = try {
            c.responseCode
            c.headerFields.entries.joinToString("\n") { (k, v) -> "${k ?: ""}: ${v.joinToString("; ")}" }.lowercase()
        } finally { c.disconnect() }
        val sigs = linkedMapOf(
            "Cloudflare" to listOf("cf-ray", "cloudflare"),
            "Sucuri" to listOf("x-sucuri-id", "sucuri"),
            "Akamai" to listOf("akamai", "x-akamai"),
            "Imperva/Incapsula" to listOf("x-iinfo", "incap_ses", "visid_incap"),
            "AWS CloudFront" to listOf("x-amz-cf-id", "cloudfront"),
            "Fastly" to listOf("x-fastly", "fastly"),
            "StackPath" to listOf("x-sp-"),
            "Azure Front Door" to listOf("x-azure-ref", "azurefd")
        )
        val found = sigs.filter { (_, keys) -> keys.any { headers.contains(it) } }.keys
        out("// HASIL\n")
        if (found.isEmpty()) out("Tidak ada WAF/CDN populer terdeteksi dari header (bisa saja tetap pakai WAF custom/di level jaringan).\n")
        else out("Terdeteksi : ${found.joinToString(", ")}\n")
        out("\n// ANALISA OTOMATIS\n")
        if (found.isNotEmpty()) {
            out("-> Permintaan dari tool command-line (curl/scanner) kemungkinan akan diblok atau dikasih\n")
            out("   halaman tantangan oleh ${found.first()}. Itu normal, bukan berarti situsnya error.\n")
            out("-> Scan port/konten langsung ke origin server bisa gagal selama di belakang ${found.first()}.\n")
        } else {
            out("-> Situs tampaknya diakses langsung ke server asal, tanpa CDN/WAF populer di depannya.\n")
            out("-> Pastikan firewall di server sendiri (ufw/iptables) aktif karena tidak ada lapisan CDN.\n")
        }
    }

    /** Cek SPF dan DMARC lewat DNS-over-HTTPS publik (Google), untuk audit keamanan email domain sendiri. */
    private fun txtLookup(name: String): List<String> {
        val body = httpGet("https://dns.google/resolve?name=${URLEncoder.encode(name, "UTF-8")}&type=TXT")
        val arr = JSONObject(body).optJSONArray("Answer") ?: return emptyList()
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val data = arr.getJSONObject(i).optString("data", "").trim('"')
            if (data.isNotBlank()) out.add(data)
        }
        return out
    }

    fun emailSecurity(domain0: String) {
        val d = domain0.trim().lowercase()
        if (!validHost(d)) { out("[!] Domain tidak valid\n"); return }
        val spf = txtLookup(d).filter { it.startsWith("v=spf1", true) }
        val dmarc = txtLookup("_dmarc.$d").filter { it.startsWith("v=DMARC1", true) }
        out("// SPF\n")
        if (spf.isEmpty()) out("[!] Tidak ada record SPF\n")
        else spf.forEach { out("$it\n") }
        out("\n// DMARC\n")
        if (dmarc.isEmpty()) out("[!] Tidak ada record DMARC\n")
        else dmarc.forEach { out("$it\n") }
        out("\n// ANALISA OTOMATIS\n")
        when {
            spf.isEmpty() -> out("[!] Tanpa SPF, email atas nama domain ini gampang dipalsukan (spoofing).\n")
            spf.any { it.contains("+all") } -> out("[!] SPF ada tapi '+all' artinya SEMUA server diizinkan kirim, ini longgar sekali.\n")
            spf.any { it.contains("-all") } -> out("[ OK ] SPF ketat (-all), hanya server terdaftar yang boleh kirim.\n")
            spf.any { it.contains("~all") } -> out("[ SEDANG ] SPF soft-fail (~all), email mencurigakan ditandai tapi tidak ditolak tegas.\n")
            else -> out("SPF ada, tapi kebijakan all-nya tidak baku dicek otomatis.\n")
        }
        when {
            dmarc.isEmpty() -> out("[!] Tanpa DMARC, laporan pemalsuan domain tidak ada dan kebijakan reject/quarantine tidak aktif.\n")
            dmarc.any { it.contains("p=reject", true) } -> out("[ OK ] DMARC policy reject, paling ketat.\n")
            dmarc.any { it.contains("p=quarantine", true) } -> out("[ SEDANG ] DMARC policy quarantine, email palsu masuk ke folder spam.\n")
            dmarc.any { it.contains("p=none", true) } -> out("[!] DMARC ada tapi policy 'none', hanya memantau, belum memblokir apa pun.\n")
            else -> out("DMARC ada, kebijakan tidak terbaca otomatis.\n")
        }
    }

    /** Enumerasi subdomain lewat log sertifikat publik (crt.sh), murni pasif, tanpa menyentuh target. */
    fun subdomains(domain0: String) {
        val d = domain0.trim().lowercase()
        if (!validHost(d)) { out("[!] Domain tidak valid\n"); return }
        out("Mengambil data crt.sh (bisa agak lama)...\n\n")
        val body = try { httpGet("https://crt.sh/?q=%25.$d&output=json") } catch (e: Exception) {
            out("[!] Gagal mengambil data: ${e.message}\n"); return
        }
        val names = sortedSetOf<String>()
        try {
            val arr = org.json.JSONArray(body)
            for (i in 0 until arr.length()) {
                val nv = arr.getJSONObject(i).optString("name_value", "")
                nv.split("\n").forEach { s -> if (s.isNotBlank() && !s.startsWith("*")) names.add(s.trim()) }
            }
        } catch (e: Exception) {
            out("[!] Format data tidak terbaca\n"); return
        }
        out("// SUBDOMAIN DITEMUKAN (${names.size})\n")
        names.take(60).forEach { out("$it\n") }
        if (names.size > 60) out("… dan ${names.size - 60} lagi\n")
        out("\n// ANALISA OTOMATIS\n")
        out(if (names.size > 25) "[!] Cukup banyak subdomain publik tercatat, cek satu-satu apakah semuanya masih dipakai.\n"
            else "Jumlah subdomain wajar, tetap cek apakah ada yang sudah tidak terpakai tapi DNS-nya masih aktif.\n")
    }

    // ---------- NETWORK TAMBAHAN ----------
    fun speedtest() {
        out("Tes unduh ~5 MB, mohon tunggu...\n\n")
        val url = URL("http://ipv4.download.thinkbroadband.com/5MB.zip")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 20000
        val start = System.currentTimeMillis()
        var total = 0L
        try {
            c.inputStream.use { ins ->
                val buf = ByteArray(16384)
                while (!cancelled) {
                    val n = ins.read(buf)
                    if (n < 0) break
                    total += n
                }
            }
        } finally { c.disconnect() }
        val secs = (System.currentTimeMillis() - start) / 1000.0
        if (secs <= 0 || total == 0L) { out("[!] Gagal mengambil data uji\n"); return }
        val mbps = (total * 8.0 / 1_000_000.0) / secs
        out("Data diambil : ${"%.2f".format(total / 1_000_000.0)} MB\n")
        out("Waktu        : ${"%.1f".format(secs)} detik\n")
        out("\n// ANALISA OTOMATIS\n")
        out("Kecepatan unduh : ${"%.1f".format(mbps)} Mbps\n")
        out(when {
            mbps < 1 -> "[!] Sangat lambat, kemungkinan sinyal lemah atau kuota habis ke kecepatan dasar.\n"
            mbps < 5 -> "[ SEDANG ] Cukup untuk browsing/chat, berat untuk video HD/upload besar.\n"
            mbps < 25 -> "[ OK ] Baik untuk streaming HD dan video call.\n"
            else -> "[ OK ] Cepat, cukup untuk kerja berat/streaming 4K.\n"
        })
        out("Catatan: hasil dari satu server uji saja, bisa beda dengan speedtest resmi.\n")
    }

    private fun ensureLocationPermission(act: Activity): Boolean {
        val fine = "android.permission.ACCESS_FINE_LOCATION"
        if (ContextCompat.checkSelfPermission(ctx, fine) != PackageManager.PERMISSION_GRANTED) {
            out("[!] Butuh izin lokasi untuk baca info WiFi (aturan Android, bukan launcher ini).\n")
            out("Izin sedang diminta, kalau muncul dialog ketuk Izinkan, lalu jalankan tool ini lagi.\n")
            ActivityCompat.requestPermissions(act, arrayOf(fine), 91)
            return false
        }
        return true
    }

    private fun wifiChannel24(freqMHz: Int): Int = (freqMHz - 2412) / 5 + 1

    private fun wifiSecType(caps: String): String = when {
        caps.contains("WPA3") -> "WPA3"
        caps.contains("WPA2") -> "WPA2"
        caps.contains("WPA") -> "WPA"
        caps.contains("WEP") -> "WEP"
        else -> "OPEN"
    }

    fun wifiScan(act: Activity) {
        if (!ensureLocationPermission(act)) return
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION") wm.startScan()
        Thread.sleep(3000)
        @Suppress("DEPRECATION") val results = wm.scanResults?.sortedByDescending { it.level } ?: emptyList()
        if (results.isEmpty()) { out("[!] Tidak ada hasil (coba lagi, atau aktifkan WiFi dulu)\n"); return }
        out("${results.size} jaringan ditemukan\n\n")
        var openCount = 0
        var wpsCount = 0
        results.take(30).forEach {
            val sec = wifiSecType(it.capabilities)
            val wps = it.capabilities.contains("WPS")
            if (sec == "OPEN") openCount++
            if (wps) wpsCount++
            val ch = if (it.frequency in 2400..2500) "ch${wifiChannel24(it.frequency)}" else "${it.frequency}MHz"
            out("${it.SSID.ifBlank { "(tersembunyi)" }}  ${it.level} dBm  $ch  $sec${if (wps) " WPS" else ""}\n")
        }
        out("\n// ANALISA OTOMATIS\n")
        val ch24 = results.filter { it.frequency in 2400..2500 }
        val chCount = ch24.groupingBy { wifiChannel24(it.frequency) }.eachCount()
        val candidates = listOf(1, 6, 11)
        val best = candidates.minByOrNull { chCount[it] ?: 0 }
        out("Channel 2.4GHz paling lega buat AP baru: CH $best (${chCount[best] ?: 0} jaringan di situ)\n")
        if (openCount > 0) out("[!] $openCount jaringan tanpa enkripsi (OPEN) terdeteksi di sekitar.\n")
        if (wpsCount > 0) out("[!] $wpsCount jaringan masih WPS aktif, WPS rawan dibobol brute-force PIN.\n")
        if (ch24.size > 8) out("[!] Padat di 2.4GHz (${ch24.size} jaringan), pertimbangkan pindah AP sendiri ke 5GHz kalau perangkatnya support.\n")
    }

    fun wifiInfo(act: Activity) {
        if (!ensureLocationPermission(act)) return
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION") val wi = wm.connectionInfo
        if (wi == null || wi.networkId == -1) { out("[!] Tidak sedang terhubung ke WiFi.\n"); return }
        val rssi = wi.rssi
        val quality = ((rssi + 100) * 2).coerceIn(0, 100)
        out("SSID       : ${wi.ssid}\n")
        @Suppress("DEPRECATION") out("BSSID      : ${wi.bssid ?: "?"}\n")
        out("SINYAL     : $rssi dBm (${quality}%)\n")
        @Suppress("DEPRECATION") out("KECEPATAN  : ${wi.linkSpeed} Mbps\n")
        val ch = if (wi.frequency in 2400..2500) "CH ${wifiChannel24(wi.frequency)} (2.4GHz)" else "${wi.frequency} MHz (5GHz)"
        out("FREKUENSI  : $ch\n")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val sec = when (wi.currentSecurityType) {
                0 -> "OPEN"
                1 -> "WEP"
                2 -> "PSK (WPA/WPA2)"
                3 -> "EAP (WPA Enterprise)"
                4 -> "SAE (WPA3)"
                5 -> "EAP Suite-B"
                6 -> "OWE (Enhanced Open)"
                7 -> "WAPI PSK"
                8 -> "WAPI CERT"
                else -> "tidak diketahui"
            }
            out("KEAMANAN   : $sec\n")
        }
        out("\n// ANALISA OTOMATIS\n")
        out(when {
            rssi > -50 -> "[ OK ] Sinyal sangat kuat.\n"
            rssi > -67 -> "[ OK ] Sinyal baik, cukup untuk browsing/streaming.\n"
            rssi > -75 -> "[ SEDANG ] Sinyal lemah, mulai terasa putus-putus untuk video call.\n"
            else -> "[!] Sinyal sangat lemah, pertimbangkan pindah lebih dekat ke AP atau pasang repeater.\n"
        })
    }

    fun wifiMonitor(act: Activity) {
        if (!ensureLocationPermission(act)) return
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        out("Monitor sinyal real-time, geser HP ke lokasi yang mau dicek, ketuk STOP untuk berhenti\n\n")
        var n = 0
        val samples = mutableListOf<Int>()
        while (!cancelled && n < 300) {
            @Suppress("DEPRECATION") val wi = wm.connectionInfo
            if (wi == null || wi.networkId == -1) { out("[!] Tidak terhubung ke WiFi\n"); break }
            val rssi = wi.rssi
            samples.add(rssi)
            val bars = ((rssi + 100) / 10).coerceIn(0, 5)
            out("$rssi dBm  [${"█".repeat(bars)}${"░".repeat(5 - bars)}]\n")
            n++
            Thread.sleep(1000)
        }
        if (samples.isNotEmpty()) {
            out("\n// ANALISA OTOMATIS\n")
            out("Sampel : ${samples.size} | min/avg/max : ${samples.min()}/${"%.0f".format(samples.average())}/${samples.max()} dBm\n")
            val range = samples.max() - samples.min()
            out(if (range > 20) "[!] Sinyal berubah-ubah drastis di area ini, kemungkinan ada titik mati (dead spot).\n"
                else "Sinyal relatif stabil di sepanjang area yang dicek.\n")
        }
    }

    fun geoip(input: String) {
        val q = input.trim()
        if (q.isEmpty()) { out("[!] Isi IP atau domain\n"); return }
        val body = httpGet("http://ip-api.com/json/$q")
        val j = JSONObject(body)
        if (j.optString("status") != "success") {
            out("[!] Gagal: ${j.optString("message", "tidak diketahui")}\n"); return
        }
        out("IP       : ${j.optString("query")}\n")
        out("NEGARA   : ${j.optString("country")}\n")
        out("WILAYAH  : ${j.optString("regionName")}\n")
        out("KOTA     : ${j.optString("city")}\n")
        out("ISP      : ${j.optString("isp")}\n")
        out("ORG      : ${j.optString("org")}\n")
        out("KOORDINAT: ${j.optDouble("lat")}, ${j.optDouble("lon")}\n")
        out("\n// ANALISA OTOMATIS\n")
        out("Lokasi perkiraan berdasarkan database IP publik, akurasi kota bisa meleset.\n")
    }

    fun wol(input: String) {
        val mac = input.trim().replace("-", ":").uppercase()
        if (!Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$").matches(mac)) {
            out("[!] Format MAC salah. Contoh: AA:BB:CC:DD:EE:FF\n"); return
        }
        val bytes = mac.split(":").map { it.toInt(16).toByte() }
        val packet = ByteArray(6) { 0xFF.toByte() } + ByteArray(16 * 6).also {
            for (i in 0 until 16) System.arraycopy(bytes.toByteArray(), 0, it, i * 6, 6)
        }
        val socket = DatagramSocket()
        socket.broadcast = true
        socket.send(DatagramPacket(packet, packet.size, InetAddress.getByName("255.255.255.255"), 9))
        socket.close()
        out("Magic packet terkirim ke broadcast jaringan untuk MAC $mac\n")
        out("\n// ANALISA OTOMATIS\n")
        out("Ini cuma kirim sinyal bangun, perangkat tujuan baru nyala kalau 'Wake on LAN' aktif\n")
        out("di BIOS/pengaturan jaringannya dan terhubung ke jaringan kabel/WiFi yang sama.\n")
    }

    fun pingLoop(host: String) {
        val h = host.trim()
        if (!validHost(h)) { out("[!] Host tidak valid\n"); return }
        var sent = 0
        var lost = 0
        val rtts = mutableListOf<Double>()
        out("Ping terus-menerus ke $h, ketuk STOP untuk berhenti\n\n")
        while (!cancelled && sent < 200) {
            sent++
            val txt = runPing(arrayOf("/system/bin/ping", "-c", "1", "-W", "2", h))
            val ms = Regex("""time=([\d.]+)""").find(txt)?.groupValues?.get(1)?.toDoubleOrNull()
            if (ms != null) { rtts.add(ms); out("seq=$sent  ${ms} ms\n") } else { lost++; out("seq=$sent  TIMEOUT\n") }
            Thread.sleep(400)
        }
        out("\n// ANALISA OTOMATIS\n")
        out("Terkirim : $sent | Hilang : $lost (${"%.0f".format(if (sent > 0) lost * 100.0 / sent else 0.0)}%)\n")
        if (rtts.isNotEmpty()) {
            out("RTT min/avg/max : ${"%.1f".format(rtts.min())}/${"%.1f".format(rtts.average())}/${"%.1f".format(rtts.max())} ms\n")
        }
        out(when {
            sent == 0 -> ""
            lost * 100.0 / sent > 10 -> "[!] Banyak paket hilang, koneksi tidak stabil.\n"
            rtts.isNotEmpty() && rtts.average() > 150 -> "[ SEDANG ] Koneksi stabil tapi latensi cukup tinggi.\n"
            else -> "[ OK ] Koneksi stabil dan responsif.\n"
        })
    }

    // ---------- SECURITY TAMBAHAN ----------
    fun cookieCheck(input: String) {
        val t = input.trim()
        if (t.isEmpty()) { out("[!] Isi URL\n"); return }
        val u = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.instanceFollowRedirects = true
        try {
            c.responseCode
            val cookies = c.headerFields["Set-Cookie"] ?: emptyList()
            if (cookies.isEmpty()) { out("Tidak ada cookie yang diset situs ini.\n"); return }
            out("// COOKIE DITEMUKAN (${cookies.size})\n")
            var weak = 0
            cookies.forEach { ck ->
                val name = ck.substringBefore("=")
                val secure = ck.contains("Secure", true)
                val httpOnly = ck.contains("HttpOnly", true)
                val sameSite = Regex("(?i)SameSite=(\\w+)").find(ck)?.groupValues?.get(1) ?: "(tidak diset)"
                if (!secure || !httpOnly) weak++
                out("$name : Secure=${if (secure) "ya" else "TIDAK"}  HttpOnly=${if (httpOnly) "ya" else "TIDAK"}  SameSite=$sameSite\n")
            }
            out("\n// ANALISA OTOMATIS\n")
            out(if (weak == 0) "[ OK ] Semua cookie punya flag keamanan lengkap.\n"
                else "[!] $weak cookie kurang flag Secure/HttpOnly, rawan dicuri lewat jaringan/skrip jahat.\n")
        } finally { c.disconnect() }
    }

    fun secAndRobots(input: String) {
        val t = input.trim().removePrefix("http://").removePrefix("https://").substringBefore("/")
        if (!validHost(t)) { out("[!] Domain tidak valid\n"); return }
        out("// SECURITY.TXT\n")
        try {
            val s = httpGet("https://$t/.well-known/security.txt")
            out(s.take(1200) + "\n")
        } catch (e: Exception) {
            out("(tidak ada security.txt, situs belum punya kontak pelaporan kerentanan resmi)\n")
        }
        out("\n// ROBOTS.TXT\n")
        val robots = try { httpGet("https://$t/robots.txt") } catch (e: Exception) { "" }
        if (robots.isBlank()) out("(tidak ada robots.txt)\n")
        else {
            out(robots.take(1500) + "\n")
            val disallow = robots.lines().count { it.trim().startsWith("Disallow", true) }
            out("\n// ANALISA OTOMATIS\n")
            out("$disallow baris Disallow ditemukan. Baris ini JUSTRU menunjukkan path yang ada ke publik,\n")
            out("jangan taruh path rahasia/admin di sini kalau tidak mau ketahuan ada.\n")
        }
    }

    fun cveSearch(keyword: String) {
        val k = keyword.trim()
        if (k.isEmpty()) { out("[!] Isi nama software, contoh: wordpress 6.0\n"); return }
        val body = httpGet("https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch=${URLEncoder.encode(k, "UTF-8")}&resultsPerPage=10")
        val arr = JSONObject(body).optJSONArray("vulnerabilities") ?: JSONArray()
        if (arr.length() == 0) { out("Tidak ada CVE publik yang cocok dengan kata kunci ini.\n"); return }
        out("// ${arr.length()} CVE DITEMUKAN\n\n")
        var highCount = 0
        for (i in 0 until arr.length()) {
            val cve = arr.getJSONObject(i).getJSONObject("cve")
            val id = cve.optString("id")
            val desc = cve.optJSONArray("descriptions")?.optJSONObject(0)?.optString("value") ?: ""
            val metrics = cve.optJSONObject("metrics")
            val v31 = metrics?.optJSONArray("cvssMetricV31")?.optJSONObject(0)?.optJSONObject("cvssData")
            val score = v31?.optDouble("baseScore")
            val sev = v31?.optString("baseSeverity")
            if (sev != null && (sev.equals("HIGH", true) || sev.equals("CRITICAL", true))) highCount++
            out("$id  [${sev ?: "?"} ${score ?: ""}]\n${desc.take(180)}\n\n")
        }
        out("// ANALISA OTOMATIS\n")
        out(if (highCount > 0) "[!] $highCount dari hasil ini tergolong HIGH/CRITICAL, prioritaskan update versi software ini.\n"
            else "Tidak ada yang HIGH/CRITICAL di 10 hasil teratas, tetap cek versi yang dipakai sesuai CVE di atas.\n")
    }

    fun httpHeaders(input: String) {
        val t = input.trim()
        if (t.isEmpty()) { out("[!] Isi URL\n"); return }
        val u = if (t.startsWith("http://") || t.startsWith("https://")) t else "https://$t"
        val c = URL(u).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 7000
        c.readTimeout = 7000
        c.setRequestProperty("User-Agent", "CyberLauncher/1.0")
        try {
            out("HTTP ${c.responseCode} ${c.responseMessage}\n")
            for ((k, v) in c.headerFields) {
                if (k != null) out("$k: ${v.joinToString("; ")}\n")
            }
            out("\n// CEK HEADER KEAMANAN\n")
            val checklist = listOf(
                "Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options",
                "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy"
            )
            var ok = 0
            checklist.forEach {
                val present = c.getHeaderField(it) != null
                if (present) ok++
                out("${if (present) "[ OK ]" else "[MISS]"} $it\n")
            }
            out("\n// ANALISA OTOMATIS\n")
            out("Skor header keamanan: $ok / ${checklist.size}\n")
            out(when {
                ok == checklist.size -> "[ OK ] Lengkap, konfigurasi header keamanan sudah bagus.\n"
                ok >= checklist.size - 2 -> "[ SEDANG ] Sebagian besar ada, lengkapi yang MISS di atas kalau bisa.\n"
                else -> "[!] Banyak header keamanan yang hilang, situs rentan clickjacking/XSS/sniffing.\n"
            })
            if (u.startsWith("http://")) out("[!] Koneksi TIDAK terenkripsi (HTTP), data bisa disadap di jaringan publik.\n")
        } finally {
            c.disconnect()
        }
    }

    fun sslCheck(input: String) {
        val raw = input.trim().removePrefix("https://").substringBefore("/")
        val host = raw.substringBefore(":")
        val port = raw.substringAfter(":", "443").toIntOrNull() ?: 443
        if (!validHost(host)) { out("[!] Host tidak valid\n"); return }
        val f = SSLSocketFactory.getDefault() as SSLSocketFactory
        val plain = Socket()
        plain.connect(InetSocketAddress(host, port), 7000)
        val s = f.createSocket(plain, host, port, true) as SSLSocket
        s.soTimeout = 7000
        s.use {
            it.startHandshake()
            val sess = it.session
            out("PROTOCOL : ${sess.protocol}\n")
            out("CIPHER   : ${sess.cipherSuite}\n")
            out("HOSTNAME : ${if (HttpsURLConnection.getDefaultHostnameVerifier().verify(host, sess)) "cocok" else "[!] TIDAK COCOK"}\n")
            val certs = sess.peerCertificates
            out("CHAIN    : ${certs.size} sertifikat\n\n")
            val c = certs[0] as X509Certificate
            out("SUBJECT  : ${c.subjectX500Principal.name}\n")
            out("ISSUER   : ${c.issuerX500Principal.name}\n")
            out("DARI     : ${c.notBefore}\n")
            out("SAMPAI   : ${c.notAfter}\n")
            out("ALGO     : ${c.sigAlgName}\n")
            val san = c.subjectAlternativeNames?.mapNotNull { x -> x.getOrNull(1)?.toString() }?.take(8)
            if (!san.isNullOrEmpty()) out("SAN      : ${san.joinToString(", ")}\n")
            val days = (c.notAfter.time - System.currentTimeMillis()) / 86400000L
            out("\n// ANALISA OTOMATIS\n")
            when {
                days < 0 -> out("[!] SERTIFIKAT SUDAH KADALUARSA, browser akan menolak/memberi peringatan.\n")
                days < 30 -> out("[!] Segera kadaluarsa: $days hari lagi, segera perpanjang.\n")
                else -> out("[ OK ] Sertifikat masih berlaku $days hari.\n")
            }
            when {
                sess.protocol.contains("1.3") -> out("[ OK ] Pakai TLS 1.3, protokol terbaru dan paling aman.\n")
                sess.protocol.contains("1.2") -> out("[ SEDANG ] Pakai TLS 1.2, masih aman tapi pertimbangkan upgrade ke 1.3.\n")
                else -> out("[!] Protokol ${sess.protocol} sudah usang/rentan, segera upgrade server.\n")
            }
        }
    }

    // ---------- SECURITY ----------
    fun hash(t: String) {
        if (t.isEmpty()) { out("[!] Isi teks\n"); return }
        for (a in listOf("MD5", "SHA-1", "SHA-256", "SHA-512")) {
            out("$a:\n${hex(MessageDigest.getInstance(a).digest(t.toByteArray()))}\n\n")
        }
    }

    fun encode(t: String) {
        if (t.isEmpty()) { out("[!] Isi teks\n"); return }
        val b = t.toByteArray()
        out("BASE64 : ${Base64.getEncoder().encodeToString(b)}\n")
        out("B64URL : ${Base64.getUrlEncoder().withoutPadding().encodeToString(b)}\n")
        out("URL    : ${URLEncoder.encode(t, "UTF-8")}\n")
        out("HEX    : ${hex(b)}\n")
    }

    fun decode(t0: String) {
        val t = t0.trim()
        var any = false
        fun printable(s: String) = s.isNotEmpty() && s.all { it >= ' ' || it.isWhitespace() }
        try {
            val s = String(Base64.getDecoder().decode(t), Charsets.UTF_8)
            if (printable(s)) { out("BASE64 : $s\n"); any = true }
        } catch (e: Exception) {
            try {
                val s = String(Base64.getUrlDecoder().decode(t), Charsets.UTF_8)
                if (printable(s)) { out("B64URL : $s\n"); any = true }
            } catch (e2: Exception) { }
        }
        if (t.contains('%') || t.contains('+')) {
            try { out("URL    : ${URLDecoder.decode(t, "UTF-8")}\n"); any = true } catch (e: Exception) { }
        }
        if (Regex("^([0-9a-fA-F]{2})+$").matches(t)) {
            val s = String(t.chunked(2).map { it.toInt(16).toByte() }.toByteArray(), Charsets.UTF_8)
            if (printable(s)) { out("HEX    : $s\n"); any = true }
        }
        if (!any) out("[!] Tidak ada format yang cocok\n")
    }

    fun passGen(arg: String) {
        val len = (arg.trim().toIntOrNull() ?: 16).coerceIn(8, 64)
        val rnd = SecureRandom()
        val sets = listOf(
            "abcdefghijklmnopqrstuvwxyz", "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
            "0123456789", "!@#%^&*()-_=+[]{}?"
        )
        val all = sets.joinToString("")
        out("Panjang $len | ~${(len * ln(all.length.toDouble()) / ln(2.0)).toInt()} bit\n\n")
        repeat(5) {
            val c = sets.map { s -> s[rnd.nextInt(s.length)] }.toMutableList()
            while (c.size < len) c.add(all[rnd.nextInt(all.length)])
            out(c.shuffled(rnd).joinToString("") + "\n")
        }
    }

    fun passCheck(pw: String) {
        if (pw.isEmpty()) { out("[!] Isi password\n"); return }
        var pool = 0
        if (pw.any { it.isLowerCase() }) pool += 26
        if (pw.any { it.isUpperCase() }) pool += 26
        if (pw.any { it.isDigit() }) pool += 10
        if (pw.any { !it.isLetterOrDigit() }) pool += 33
        if (pool < 10) pool = 10
        var bits = pw.length * ln(pool.toDouble()) / ln(2.0)
        bits *= (pw.toSet().size.toDouble() / pw.length).coerceAtLeast(0.3)
        val common = listOf("password", "123456", "qwerty", "admin", "letmein", "iloveyou", "welcome", "abc123", "111111", "kata")
        val isCommon = common.any { pw.lowercase().contains(it) }
        if (isCommon) bits = minOf(bits, 25.0)
        val secs = 2.0.pow(bits) / 2.0 / 1e10
        val time = when {
            secs < 1 -> "instan"
            secs < 60 -> "${secs.toInt()} detik"
            secs < 3600 -> "${(secs / 60).toInt()} menit"
            secs < 86400 -> "${(secs / 3600).toInt()} jam"
            secs < 31536000.0 -> "${(secs / 86400).toInt()} hari"
            secs < 3.15e16 -> "${(secs / 31536000).toLong()} tahun"
            else -> "miliaran tahun+"
        }
        val rate = when {
            bits < 28 -> "SANGAT LEMAH"
            bits < 36 -> "LEMAH"
            bits < 60 -> "SEDANG"
            bits < 80 -> "KUAT"
            else -> "SANGAT KUAT"
        }
        out("PANJANG : ${pw.length}\nENTROPI : ~${bits.toInt()} bit\nNILAI   : $rate\n")
        out("CRACK   : ~$time (asumsi 10 miliar tebakan/detik)\n")
        if (isCommon) out("[!] Mengandung pola/kata umum\n")
        out("\nDicek lokal, tidak dikirim ke mana pun.\n")
    }

    fun pwned(pw: String) {
        if (pw.isEmpty()) { out("[!] Isi password\n"); return }
        val sha = hex(MessageDigest.getInstance("SHA-1").digest(pw.toByteArray())).uppercase()
        val pre = sha.substring(0, 5)
        val suf = sha.substring(5)
        out("Hanya 5 karakter awal hash yang dikirim (k-anonymity).\n\n")
        val body = httpGet("https://api.pwnedpasswords.com/range/$pre")
        val line = body.lineSequence().firstOrNull { it.startsWith(suf, ignoreCase = true) }
        val count = line?.substringAfter(":")?.trim()?.toLongOrNull() ?: 0L
        if (count > 0) out("[!] BOCOR: muncul $count kali di database kebocoran. JANGAN dipakai.\n")
        else out("[ OK ] Tidak ditemukan di database kebocoran publik.\n")
    }

    fun jwt(token: String) {
        val p = token.trim().split(".")
        if (p.size < 2) { out("[!] Bukan format JWT (header.payload.signature)\n"); return }
        fun dec(s: String): String = String(Base64.getUrlDecoder().decode(s), Charsets.UTF_8)
        fun pretty(s: String) = try { JSONObject(s).toString(2) } catch (e: Exception) { s }
        val header = dec(p[0])
        val payload = dec(p[1])
        out("HEADER:\n${pretty(header)}\n\nPAYLOAD:\n${pretty(payload)}\n\n")
        try {
            val alg = JSONObject(header).optString("alg")
            if (alg.equals("none", true)) out("[!] alg=none: token tanpa tanda tangan, berbahaya\n")
            val exp = JSONObject(payload).optLong("exp", 0L)
            if (exp > 0) {
                out(if (exp * 1000 < System.currentTimeMillis()) "[!] Token sudah KADALUARSA\n" else "[ OK ] Token belum kadaluarsa\n")
            }
        } catch (e: Exception) { }
        out("Catatan: tanda tangan TIDAK diverifikasi.\n")
    }

    fun appAudit() {
        val pm = ctx.packageManager
        val danger = mapOf(
            "android.permission.CAMERA" to "KAMERA",
            "android.permission.RECORD_AUDIO" to "MIC",
            "android.permission.ACCESS_FINE_LOCATION" to "LOKASI",
            "android.permission.ACCESS_BACKGROUND_LOCATION" to "LOKASI-BG",
            "android.permission.READ_SMS" to "SMS",
            "android.permission.READ_CONTACTS" to "KONTAK",
            "android.permission.READ_CALL_LOG" to "LOG-TELP",
            "android.permission.READ_EXTERNAL_STORAGE" to "STORAGE",
            "android.permission.MANAGE_EXTERNAL_STORAGE" to "SEMUA-FILE"
        )
        @Suppress("DEPRECATION")
        val pkgs: List<PackageInfo> = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        val rows = mutableListOf<Triple<Int, String, String>>()
        for (pi in pkgs) {
            if (cancelled) return
            val flags = pi.applicationInfo?.flags ?: 0
            if ((flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            val perms = pi.requestedPermissions ?: continue
            val pf = pi.requestedPermissionsFlags ?: continue
            val got = mutableListOf<String>()
            for (i in perms.indices) {
                val granted = (pf[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                val tag = danger[perms[i]]
                if (granted && tag != null) got.add(tag)
            }
            if (got.isNotEmpty()) {
                val label = pi.applicationInfo?.let { pm.getApplicationLabel(it).toString() } ?: pi.packageName
                rows.add(Triple(got.size, label, got.joinToString(",")))
            }
        }
        out("AUDIT IZIN APP TERPASANG (izin sensitif yang sedang AKTIF)\n\n")
        rows.sortedByDescending { it.first }.take(30).forEach {
            out("[${it.first}] ${it.second}\n     ${it.third}\n")
        }
        out("\n${rows.size} app punya izin sensitif. Cabut izin yang tidak perlu di Info Aplikasi > Izin.\n")
    }
}
