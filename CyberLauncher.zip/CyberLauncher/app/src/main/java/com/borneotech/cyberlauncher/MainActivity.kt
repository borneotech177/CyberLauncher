package com.borneotech.cyberlauncher

import android.app.ActivityManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

data class AppItem(val label: String, val pkg: String, val intent: Intent, val icon: Drawable)

class MainActivity : AppCompatActivity() {

    private val all = mutableListOf<AppItem>()
    private val shown = mutableListOf<AppItem>()
    private lateinit var adapter: AppAdapter
    private lateinit var stats: TextView
    private lateinit var notifBox: LinearLayout
    private lateinit var search: EditText
    private lateinit var grid: RecyclerView
    private val handler = Handler(Looper.getMainLooper())

    private val ticker = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 3000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        stats = findViewById(R.id.stats)
        notifBox = findViewById(R.id.notifBox)
        search = findViewById(R.id.search)
        grid = findViewById(R.id.grid)

        adapter = AppAdapter()
        grid.layoutManager = GridLayoutManager(this, 4)
        grid.adapter = adapter

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) = filter(s?.toString() ?: "")
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO && shown.isNotEmpty()) {
                launch(shown[0])
                search.setText("")
            }
            true
        }

        findViewById<View>(R.id.btnDial).setOnClickListener { safeStart(Intent(Intent.ACTION_DIAL)) }
        findViewById<View>(R.id.btnCam).setOnClickListener { safeStart(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) }
        findViewById<View>(R.id.btnWeb).setOnClickListener {
            safeStart(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")))
        }
        findViewById<View>(R.id.btnSys).setOnClickListener { safeStart(Intent(Settings.ACTION_SETTINGS)) }
        findViewById<View>(R.id.btnNet).setOnClickListener {
            startActivity(Intent(this, ToolsActivity::class.java).putExtra("cat", "NET"))
        }
        findViewById<View>(R.id.btnSec).setOnClickListener {
            startActivity(Intent(this, ToolsActivity::class.java).putExtra("cat", "SEC"))
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        renderNotifs()
        NotificationService.listener = { runOnUiThread { renderNotifs() } }
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        NotificationService.listener = null
        handler.removeCallbacks(ticker)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Tombol Home ditekan saat sudah di launcher: reset tampilan
        search.setText("")
        grid.scrollToPosition(0)
    }

    @Deprecated("Launcher tidak boleh keluar lewat Back")
    override fun onBackPressed() { /* sengaja kosong */ }

    private fun safeStart(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membuka", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launch(a: AppItem) = safeStart(Intent(a.intent))

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(q, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    AppItem(
                        ri.loadLabel(pm).toString(),
                        ri.activityInfo.packageName,
                        Intent(Intent.ACTION_MAIN)
                            .addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        ri.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase() }
            runOnUiThread {
                all.clear()
                all.addAll(list)
                filter(search.text.toString())
            }
        }.start()
    }

    private fun filter(q: String) {
        shown.clear()
        shown.addAll(all.filter { it.label.contains(q.trim(), ignoreCase = true) })
        adapter.notifyDataSetChanged()
    }

    private fun tv(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        setTextColor(color)
        textSize = 11f
        typeface = Typeface.MONOSPACE
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setPadding(0, 5, 0, 5)
    }

    private fun renderNotifs() {
        notifBox.removeAllViews()
        val enabled = NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)
        if (!enabled) {
            notifBox.addView(tv("[!] AKSES NOTIF DITOLAK - ketuk untuk aktifkan", 0xFFFF3B3B.toInt()).apply {
                setOnClickListener { safeStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
            })
            return
        }
        val items = NotificationService.items.take(4)
        if (items.isEmpty()) {
            notifBox.addView(tv("[ OK ] tidak ada notifikasi", 0xFF1F6F4F.toInt()))
            return
        }
        for (n in items) {
            notifBox.addView(tv("> ${n.app}: ${n.title} ${n.text}".trim(), 0xFF00FF9C.toInt()).apply {
                setOnClickListener {
                    try { n.intent?.send() } catch (e: Exception) { /* abaikan */ }
                }
            })
        }
    }

    private fun bar(p: Long): String {
        val f = (p / 10).toInt().coerceIn(0, 10)
        return "█".repeat(f) + "░".repeat(10 - f)
    }

    private fun updateStats() {
        val bi = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lvl = bi?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bi?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val bat = if (lvl >= 0 && scale > 0) (lvl * 100 / scale).toLong() else 0L
        val st = bi?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL

        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = if (mi.totalMem > 0) (mi.totalMem - mi.availMem) * 100 / mi.totalMem else 0L

        val sf = StatFs(Environment.getDataDirectory().path)
        val sto = if (sf.totalBytes > 0) (sf.totalBytes - sf.availableBytes) * 100 / sf.totalBytes else 0L

        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WIFI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "SELULER"
            else -> "ONLINE"
        }
        val vpn = caps?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true

        stats.text = "BAT [${bar(bat)}] $bat%${if (chg) " +" else ""}\n" +
            "RAM [${bar(ram)}] $ram%\n" +
            "STO [${bar(sto)}] $sto%\n" +
            "NET $net | VPN ${if (vpn) "ON" else "OFF"}"
    }

    private fun appMenu(a: AppItem) {
        AlertDialog.Builder(this)
            .setTitle(a.label)
            .setItems(arrayOf("Info aplikasi", "Uninstall")) { _, w ->
                val uri = Uri.parse("package:${a.pkg}")
                if (w == 0) safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                else safeStart(Intent(Intent.ACTION_DELETE, uri))
            }
            .show()
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val icon: ImageView = v.findViewById(R.id.icon)
            val label: TextView = v.findViewById(R.id.label)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_app, p, false))

        override fun getItemCount() = shown.size

        override fun onBindViewHolder(h: VH, i: Int) {
            val a = shown[i]
            h.icon.setImageDrawable(a.icon)
            h.label.text = a.label
            h.itemView.setOnClickListener { launch(a) }
            h.itemView.setOnLongClickListener { appMenu(a); true }
        }
    }
}
