package com.borneotech.cyberlauncher

import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.atomic.AtomicInteger

/** Jembatan ke Termux lewat API resmi RUN_COMMAND. Termux harus versi F-Droid/GitHub + allow-external-apps=true. */
object TermuxBridge {
    const val PERMISSION = "com.termux.permission.RUN_COMMAND"
    private const val PKG = "com.termux"
    private const val SERVICE = "com.termux.app.RunCommandService"
    private const val ACTION_BASE = "com.borneotech.cyberlauncher.TERMUX_RESULT"
    private val seq = AtomicInteger(1000)

    fun isInstalled(ctx: Context): Boolean =
        try { ctx.packageManager.getPackageInfo(PKG, 0); true } catch (e: Exception) { false }

    fun hasPermission(ctx: Context): Boolean =
        ContextCompat.checkSelfPermission(ctx, PERMISSION) == PackageManager.PERMISSION_GRANTED

    fun requestPermission(act: Activity, code: Int) {
        ActivityCompat.requestPermissions(act, arrayOf(PERMISSION), code)
    }

    fun openTermux(ctx: Context) {
        ctx.packageManager.getLaunchIntentForPackage(PKG)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(it)
        } ?: openInstallPage(ctx)
    }

    fun openInstallPage(ctx: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/packages/com.termux/"))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Buka halaman izin "Tampil di atas aplikasi lain" khusus untuk Termux. */
    fun openOverlaySettings(ctx: Context) {
        val i = Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$PKG"))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Buka halaman pengaturan baterai khusus untuk Termux (supaya tidak dibunuh Android). */
    fun openBatterySettings(ctx: Context) {
        val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$PKG"))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    /** Kirim perintah shell ke Termux dan terima balik stdout/stderr/exit code. */
    fun run(ctx: Context, command: String, onResult: (stdout: String, stderr: String, exit: Int?) -> Unit) {
        val resultAction = "$ACTION_BASE.${seq.incrementAndGet()}"
        val filter = IntentFilter(resultAction)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, intent: Intent) {
                try { c.unregisterReceiver(this) } catch (e: Exception) { }
                val b = intent.getBundleExtra("result")
                if (b == null) {
                    val dump = intent.extras?.keySet()?.joinToString { k -> "$k=${intent.extras?.get(k)}" }
                    onResult("", "Tidak ada bundle 'result' dari Termux.${if (!dump.isNullOrBlank()) " Extras: $dump" else " Pastikan versi Termux terbaru (F-Droid/GitHub)."}", null)
                    return
                }
                val out = b.getString("stdout") ?: ""
                val err = b.getString("stderr") ?: ""
                val exit = if (b.containsKey("exitCode")) b.getInt("exitCode") else null
                val errmsg = b.getString("errmsg") ?: ""
                onResult(out, if (errmsg.isNotBlank()) "$err\n$errmsg" else err, exit)
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                ctx.registerReceiver(receiver, filter)
            }
        } catch (e: Exception) {
            onResult("", "Gagal mendaftar penerima hasil: ${e.message}", null)
            return
        }

        val pi = PendingIntent.getBroadcast(
            ctx, seq.incrementAndGet(), Intent(resultAction).setPackage(ctx.packageName),
            PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val intent = Intent("com.termux.RUN_COMMAND").apply {
            setClassName(PKG, SERVICE)
            putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash")
            putExtra("com.termux.RUN_COMMAND_ARGUMENTS", arrayOf("-c", command))
            putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home")
            putExtra("com.termux.RUN_COMMAND_BACKGROUND", true)
            putExtra("com.termux.RUN_COMMAND_PENDING_INTENT", pi)
        }
        try {
            // RUN_COMMAND_BACKGROUND=true dipasangkan dengan startService() biasa
            // (bukan startForegroundService) sesuai dokumentasi resmi Termux.
            ctx.startService(intent)
        } catch (e: Exception) {
            try { ctx.unregisterReceiver(receiver) } catch (e2: Exception) { }
            onResult(
                "",
                "Gagal memanggil Termux: ${e.message}\n" +
                    "Kemungkinan Termux belum pernah dibuka sejak HP nyala, atau izin 'Tampil di atas\n" +
                    "aplikasi lain' + baterai belum diaktifkan. Lihat panduan di tab TERMUX (ketuk CEK).",
                null
            )
        }
    }

    /** Ringkasan singkat dari output, tergantung jenis perintah. */
    fun analyze(command: String, stdout: String): String {
        val c = command.lowercase()
        val sb = StringBuilder()
        when {
            c.contains("nmap") -> {
                val open = Regex("""(\d+)/tcp\s+open\s+(\S+)""").findAll(stdout).toList()
                sb.append("Port terbuka : ${open.size}\n")
                if (open.isEmpty()) sb.append("  (tidak ada port terbuka, atau host tidak menjawab)\n")
                open.take(15).forEach { sb.append("  • ${it.groupValues[1]}/tcp  ${it.groupValues[2]}\n") }
                if (open.size > 15) sb.append("  … dan ${open.size - 15} lagi, lihat output lengkap di atas\n")
            }
            c.contains("nikto") -> {
                val findings = stdout.lines().count { it.trim().startsWith("+") && !it.contains("Target IP") }
                sb.append("Temuan nikto : $findings baris diawali '+'\n")
                sb.append(if (findings > 0) "  Baca tiap baris '+' di atas untuk detail kerentanannya.\n" else "  Tidak ada temuan mencolok.\n")
            }
            c.contains("whatweb") -> {
                sb.append("Teknologi terdeteksi tertulis di output di atas (dipisah koma).\n")
            }
            c.contains("dig") || c.contains("nslookup") -> {
                val ips = Regex("""\b(?:\d{1,3}\.){3}\d{1,3}\b""").findAll(stdout).map { it.value }.distinct().toList()
                sb.append("IP ditemukan : ${ips.joinToString(", ").ifBlank { "tidak ada" }}\n")
            }
            c.contains("traceroute") -> {
                val hops = stdout.lines().count { it.trim().firstOrNull()?.isDigit() == true }
                sb.append("Jumlah hop   : $hops\n")
            }
            c.contains("mtr") -> {
                val rows = Regex("""(\d+)\.\|--\s+\S+\s+(\d+(?:\.\d+)?)%""").findAll(stdout).toList()
                val worst = rows.maxByOrNull { it.groupValues[2].toDoubleOrNull() ?: 0.0 }
                sb.append("Hop terbaca    : ${rows.size}\n")
                if (worst != null) sb.append("Loss tertinggi : hop ${worst.groupValues[1]} (${worst.groupValues[2]}%)\n")
                val bad = rows.count { (it.groupValues[2].toDoubleOrNull() ?: 0.0) > 10.0 }
                sb.append(if (bad > 0) "[!] $bad hop dengan loss >10%, kemungkinan sumber masalah jaringan.\n" else "Loss antar hop wajar.\n")
            }
            c.contains("sslscan") -> {
                val accepted = Regex("""(?i)Accepted\s+\S+\s+\S+""").findAll(stdout).toList()
                val weak = accepted.filter { Regex("(?i)export|rc4|des|md5|null").containsMatchIn(it.value) }
                sb.append("Cipher diterima : ${accepted.size}\n")
                sb.append(if (weak.isNotEmpty()) "[!] ${weak.size} cipher LEMAH masih aktif, matikan di konfigurasi server.\n"
                    else "Tidak ada cipher lemah umum yang terdeteksi.\n")
            }
            c.contains("dirb") || c.contains("gobuster") -> {
                val found = Regex("""CODE:200""").findAll(stdout).count()
                sb.append("Path/file ditemukan (kode 200) : $found\n")
                sb.append(if (found > 0) "[!] Ada path yang terbuka, cek satu-satu apakah seharusnya tidak publik (admin, backup, .env, dll).\n"
                    else "Tidak ada path umum yang ketemu dari wordlist ini.\n")
            }
            else -> sb.append("${stdout.lines().size} baris output.\n")
        }
        return sb.toString()
    }
}
