package com.borneotech.cyberlauncher

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

data class NotifItem(
    val app: String,
    val title: String,
    val text: String,
    val intent: PendingIntent?
)

class NotificationService : NotificationListenerService() {

    override fun onListenerConnected() = refresh()
    override fun onNotificationPosted(sbn: StatusBarNotification?) = refresh()
    override fun onNotificationRemoved(sbn: StatusBarNotification?) = refresh()

    private fun refresh() {
        val pm = packageManager
        items = try {
            (activeNotifications ?: emptyArray())
                .filter {
                    it.packageName != packageName &&
                        (it.notification.flags and Notification.FLAG_GROUP_SUMMARY) == 0
                }
                .sortedByDescending { it.postTime }
                .map { sbn ->
                    val ex = sbn.notification.extras
                    val app = try {
                        pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                    } catch (e: Exception) {
                        sbn.packageName
                    }
                    NotifItem(
                        app,
                        ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "",
                        ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: "",
                        sbn.notification.contentIntent
                    )
                }
        } catch (e: Exception) {
            emptyList()
        }
        listener?.invoke()
    }

    companion object {
        @Volatile var items: List<NotifItem> = emptyList()
        @Volatile var listener: (() -> Unit)? = null
    }
}
