package com.borneotech.cyberlauncher

import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ToolsActivity : AppCompatActivity() {

    private class Def(
        val name: String,
        val cat: String,
        val hint: String,
        val run: (ToolBox, String) -> Unit
    )

    private val defs = listOf(
        Def("INFO", "NET", "Info jaringan aktif (IP, gateway, DNS, WiFi). Tanpa input.") { t, _ -> t.netInfo() },
        Def("PING", "NET", "Host/IP. Contoh: 8.8.8.8") { t, i -> t.ping(i) },
        Def("TRACE", "NET", "Traceroute. Contoh: google.com") { t, i -> t.traceroute(i) },
        Def("DNS", "NET", "Lookup domain. Contoh: github.com") { t, i -> t.dns(i) },
        Def("PORTS", "NET", "host [port]. Contoh: 192.168.1.1 1-1024 atau 22,80,443. Hanya perangkat sendiri!") { t, i -> t.portScan(i) },
        Def("LAN", "NET", "Cari perangkat aktif di WiFi /24. Tanpa input. Hanya jaringan sendiri!") { t, _ -> t.lanScan() },
        Def("SUBNET", "NET", "Kalkulator subnet. Contoh: 192.168.1.10/24") { t, i -> t.subnet(i) },
        Def("WHOIS", "NET", "Domain. Contoh: example.com") { t, i -> t.whois(i) },
        Def("HTTP", "NET", "URL: lihat header + cek header keamanan") { t, i -> t.httpHeaders(i) },
        Def("SSL", "NET", "Cek sertifikat. Contoh: github.com atau host:8443") { t, i -> t.sslCheck(i) },

        Def("HASH", "SEC", "Teks -> MD5/SHA1/SHA256/SHA512") { t, i -> t.hash(i) },
        Def("ENCODE", "SEC", "Teks -> Base64, URL, Hex") { t, i -> t.encode(i) },
        Def("DECODE", "SEC", "Tempel string Base64 / URL / Hex") { t, i -> t.decode(i) },
        Def("PASSGEN", "SEC", "Panjang (8-64), default 16") { t, i -> t.passGen(i) },
        Def("PASSCHK", "SEC", "Password -> nilai kekuatan (lokal)") { t, i -> t.passCheck(i) },
        Def("PWNED", "SEC", "Cek password bocor (HaveIBeenPwned, aman k-anonymity)") { t, i -> t.pwned(i) },
        Def("JWT", "SEC", "Tempel token JWT untuk di-decode") { t, i -> t.jwt(i) },
        Def("APPAUDIT", "SEC", "Audit izin sensitif app terpasang. Tanpa input.") { t, _ -> t.appAudit() }
    )

    private val green = 0xFF00FF9C.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val dim = 0xFF1F6F4F.toInt()

    private lateinit var chips: LinearLayout
    private lateinit var usage: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnRun: TextView
    private lateinit var tabNet: TextView
    private lateinit var tabSec: TextView

    private var current: Def? = null
    private var box: ToolBox? = null
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tools)

        chips = findViewById(R.id.chips)
        usage = findViewById(R.id.usage)
        input = findViewById(R.id.input)
        output = findViewById(R.id.output)
        scroll = findViewById(R.id.scroll)
        btnRun = findViewById(R.id.btnRun)
        tabNet = findViewById(R.id.tabNet)
        tabSec = findViewById(R.id.tabSec)

        tabNet.setOnClickListener { showCat("NET") }
        tabSec.setOnClickListener { showCat("SEC") }
        btnRun.setOnClickListener { run() }
        findViewById<View>(R.id.btnClear).setOnClickListener { output.text = "" }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) run()
            true
        }

        showCat(intent.getStringExtra("cat") ?: "NET")
    }

    override fun onDestroy() {
        super.onDestroy()
        box?.stop()
    }

    private fun showCat(cat: String) {
        tabNet.setTextColor(if (cat == "NET") green else cyan)
        tabSec.setTextColor(if (cat == "SEC") green else cyan)
        chips.removeAllViews()
        val list = defs.filter { it.cat == cat }
        for (d in list) {
            val c = TextView(this).apply {
                text = d.name
                textSize = 12f
                typeface = Typeface.MONOSPACE
                setPadding(28, 14, 28, 14)
                setBackgroundResource(R.drawable.panel_border)
                setOnClickListener { select(d) }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(0, 0, 10, 0)
            chips.addView(c, lp)
        }
        select(list.first())
    }

    private fun select(d: Def) {
        current = d
        usage.text = "[ ${d.name} ] ${d.hint}"
        input.hint = "root@borneo:~$ ${d.name.lowercase()}"
        for (i in 0 until chips.childCount) {
            val c = chips.getChildAt(i) as TextView
            c.setTextColor(if (c.text.toString() == d.name) green else cyan)
        }
    }

    private fun append(s: String) {
        output.append(s)
        if (output.length() > 80000) output.text = output.text.takeLast(60000)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun run() {
        if (running) {
            box?.stop()
            return
        }
        val d = current ?: return
        output.text = ""
        val tb = ToolBox(this) { s -> runOnUiThread { append(s) } }
        box = tb
        running = true
        btnRun.text = "[ STOP ]"
        btnRun.setTextColor(0xFFFF3B3B.toInt())
        val text = input.text.toString()
        Thread {
            try {
                d.run(tb, text)
            } catch (e: Exception) {
                if (!tb.cancelled) tb.out("[!] ${e.javaClass.simpleName}: ${e.message}\n")
            }
            runOnUiThread {
                running = false
                btnRun.text = "[ RUN ]"
                btnRun.setTextColor(green)
                append("\n[ selesai ]\n")
            }
        }.start()
    }
}
