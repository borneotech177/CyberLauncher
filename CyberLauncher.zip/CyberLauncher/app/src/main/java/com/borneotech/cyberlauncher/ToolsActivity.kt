package com.borneotech.cyberlauncher

import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ToolsActivity : AppCompatActivity() {

    private class Def(
        val name: String,
        val cat: String,
        val hint: String,
        val run: (ToolBox, String) -> Unit
    )

    private class TPreset(
        val name: String,
        val template: String? = null,
        val hint: String = "",
        val action: ((ToolsActivity) -> Unit)? = null
    )

    private val defs = listOf(
        Def("INFO", "NET", "Info jaringan aktif (IP, gateway, DNS, WiFi). Tanpa input.") { t, _ -> t.netInfo() },
        Def("PING", "NET", "Host/IP. Contoh: 8.8.8.8") { t, i -> t.ping(i) },
        Def("TRACE", "NET", "Traceroute. Contoh: google.com") { t, i -> t.traceroute(i) },
        Def("DNS", "NET", "Lookup domain. Contoh: github.com") { t, i -> t.dns(i) },
        Def("PORTS", "NET", "host [port]. Contoh: 192.168.1.1 1-1024 atau 22,80,443. Hanya perangkat sendiri!") { t, i -> t.portScan(i) },
        Def("LAN", "NET", "Cari perangkat aktif di WiFi /24. Tanpa input. Hanya jaringan sendiri!") { t, _ -> t.lanScan() },
        Def("SUBNET", "NET", "Kalkulator subnet. Contoh: 192.168.1.10/24") { t, i -> t.subnet(i) },
        Def("WHOIS", "NET", "Domain. Contoh: example.com") { t, i -> t.whois(i) },
        Def("HTTP", "NET", "URL: lihat header + cek header keamanan") { t, i -> t.httpHeaders(i) },
        Def("SSL", "NET", "Cek sertifikat. Contoh: github.com atau host:8443") { t, i -> t.sslCheck(i) },

        Def("HASH", "SEC", "Teks -> MD5/SHA1/SHA256/SHA512") { t, i -> t.hash(i) },
        Def("ENCODE", "SEC", "Teks -> Base64, URL, Hex") { t, i -> t.encode(i) },
        Def("DECODE", "SEC", "Tempel string Base64 / URL / Hex") { t, i -> t.decode(i) },
        Def("PASSGEN", "SEC", "Panjang (8-64), default 16") { t, i -> t.passGen(i) },
        Def("PASSCHK", "SEC", "Password -> nilai kekuatan (lokal)") { t, i -> t.passCheck(i) },
        Def("PWNED", "SEC", "Cek password bocor (HaveIBeenPwned, aman k-anonymity)") { t, i -> t.pwned(i) },
        Def("JWT", "SEC", "Tempel token JWT untuk di-decode") { t, i -> t.jwt(i) },
        Def("APPAUDIT", "SEC", "Audit izin sensitif app terpasang. Tanpa input.") { t, _ -> t.appAudit() }
    )

    private val termPresets = listOf(
        TPreset("CEK", hint = "Cek status Termux dan izin RUN_COMMAND") { it.checkTermux() },
        TPreset("IZIN", hint = "Minta izin RUN_COMMAND ke Termux") { it.askTermuxPermission() },
        TPreset("BUKA", hint = "Buka app Termux (opsional, untuk setting pertama)") { TermuxBridge.openTermux(it) },
        TPreset("SETUP", "pkg update -y && pkg upgrade -y && pkg install -y nmap nikto whatweb", "Install tool: nmap, nikto, whatweb"),
        TPreset("NMAP", "nmap -sV -T4 ", "Scan versi service. Tambahkan target di belakang"),
        TPreset("NMAP-FULL", "nmap -p- -T4 ", "Scan semua 65535 port. Lambat, tambahkan target"),
        TPreset("NIKTO", "nikto -h ", "Scan kerentanan web server. Tambahkan target"),
        TPreset("WHATWEB", "whatweb ", "Deteksi teknologi website. Tambahkan target"),
        TPreset("DIG", "dig ", "DNS lookup lengkap. Tambahkan domain"),
        TPreset("TRACE", "traceroute ", "Jejak rute paket. Tambahkan target"),
        TPreset("TCPDUMP", "tcpdump -i any -c 30", "Tangkap 30 paket jaringan (butuh root untuk hasil penuh)")
    )

    private val green = 0xFF00FF9C.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val red = 0xFFFF3B3B.toInt()

    private lateinit var chips: LinearLayout
    private lateinit var usage: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnRun: TextView
    private lateinit var tabNet: TextView
    private lateinit var tabSec: TextView
    private lateinit var tabTerm: TextView

    private var currentDef: Def? = null
    private var category = "NET"
    private var box: ToolBox? = null
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tools)

        chips = findViewById(R.id.chips)
        usage = findViewById(R.id.usage)
        input = findViewById(R.id.input)
        output = findViewById(R.id.output)
        scroll = findViewById(R.id.scroll)
        btnRun = findViewById(R.id.btnRun)
        tabNet = findViewById(R.id.tabNet)
        tabSec = findViewById(R.id.tabSec)
        tabTerm = findViewById(R.id.tabTerm)

        tabNet.setOnClickListener { showCat("NET") }
        tabSec.setOnClickListener { showCat("SEC") }
        tabTerm.setOnClickListener { showCat("TERM") }
        btnRun.setOnClickListener { if (category == "TERM") runTermux() else runLocal() }
        findViewById<View>(R.id.btnClear).setOnClickListener { output.text = "" }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { if (category == "TERM") runTermux() else runLocal() }
            true
        }

        showCat(intent.getStringExtra("cat") ?: "NET")
    }

    override fun onDestroy() {
        super.onDestroy()
        box?.stop()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code == 42) {
            val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
            append(if (ok) "[ OK ] Izin RUN_COMMAND diberikan.\n" else "[!] Izin RUN_COMMAND ditolak.\n")
        }
    }

    private fun setColors(sel: String) {
        tabNet.setTextColor(if (sel == "NET") green else cyan)
        tabSec.setTextColor(if (sel == "SEC") green else cyan)
        tabTerm.setTextColor(if (sel == "TERM") green else cyan)
    }

    private fun showCat(cat: String) {
        category = cat
        setColors(cat)
        chips.removeAllViews()
        if (cat == "TERM") {
            for (p in termPresets) {
                addChip(p.name) {
                    if (p.action != null) {
                        p.action.invoke(this)
                    } else {
                        usage.text = "[ ${p.name} ] ${p.hint}"
                        input.setText(p.template ?: "")
                        input.setSelection(input.text.length)
                    }
                }
            }
            usage.text = "[ TERMUX ] Jalankan perintah langsung di Termux. Pilih preset atau ketik manual, lalu RUN."
            input.hint = "root@borneo:~$ perintah bebas..."
            input.setText("")
            output.text = ""
            checkTermux()
            return
        }
        val list = defs.filter { it.cat == cat }
        for (d in list) addChip(d.name) { select(d) }
        select(list.first())
    }

    private fun addChip(name: String, onClick: () -> Unit) {
        val c = TextView(this).apply {
            text = name
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(28, 14, 28, 14)
            setBackgroundResource(R.drawable.panel_border)
            setTextColor(cyan)
            setOnClickListener {
                onClick()
                for (i in 0 until chips.childCount) {
                    (chips.getChildAt(i) as TextView).setTextColor(cyan)
                }
                setTextColor(green)
            }
        }
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 10, 0)
        chips.addView(c, lp)
    }

    private fun select(d: Def) {
        currentDef = d
        usage.text = "[ ${d.name} ] ${d.hint}"
        input.hint = "root@borneo:~$ ${d.name.lowercase()}"
        input.setText("")
    }

    private fun append(s: String) {
        output.append(s)
        if (output.length() > 80000) output.text = output.text.takeLast(60000)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setRunning(on: Boolean) {
        running = on
        btnRun.text = if (on) "[ STOP ]" else "[ RUN ]"
        btnRun.setTextColor(if (on) red else green)
    }

    private fun runLocal() {
        if (running) { box?.stop(); return }
        val d = currentDef ?: return
        output.text = ""
        val tb = ToolBox(this) { s -> runOnUiThread { append(s) } }
        box = tb
        setRunning(true)
        val text = input.text.toString()
        Thread {
            try {
                d.run(tb, text)
            } catch (e: Exception) {
                if (!tb.cancelled) tb.out("[!] ${e.javaClass.simpleName}: ${e.message}\n")
            }
            runOnUiThread { setRunning(false); append("\n[ selesai ]\n") }
        }.start()
    }

    // ---------- TERMUX ----------
    fun checkTermux() {
        val inst = TermuxBridge.isInstalled(this)
        val perm = TermuxBridge.hasPermission(this)
        val ready = inst && perm
        append("// STATUS KONEKSI TERMUX\n")
        append("${if (ready) "[ TERHUBUNG ]" else "[ BELUM SIAP ]"}\n\n")
        append("  Termux terpasang  : ${if (inst) "YA" else "TIDAK"}\n")
        append("  Izin RUN_COMMAND  : ${if (perm) "SUDAH" else "BELUM"}\n\n")
        if (!inst) append("-> Ketuk [ BUKA ] untuk pasang Termux dari F-Droid/GitHub (bukan Play Store).\n")
        else if (!perm) append("-> Ketuk [ IZIN ] untuk mengaktifkan akses RUN_COMMAND.\n")
        else append("Siap. Pilih preset di atas atau ketik perintah sendiri, lalu RUN.\n")
        append("\nCatatan setup sekali di Termux: tambahkan allow-external-apps = true\n")
        append("ke ~/.termux/termux.properties, lalu jalankan termux-reload-settings.\n")
    }

    fun askTermuxPermission() {
        if (!TermuxBridge.isInstalled(this)) {
            append("[!] Termux belum terpasang. Membuka halaman unduh...\n")
            TermuxBridge.openInstallPage(this)
            return
        }
        if (TermuxBridge.hasPermission(this)) {
            append("[ OK ] Izin sudah ada.\n")
            return
        }
        TermuxBridge.requestPermission(this, 42)
    }

    private fun runTermux() {
        if (running) { setRunning(false); return }
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) { append("[!] Isi perintah dulu\n"); return }
        if (!TermuxBridge.isInstalled(this)) {
            append("[!] Termux belum terpasang. Ketuk preset [ BUKA ] atau install dari F-Droid.\n"); return
        }
        if (!TermuxBridge.hasPermission(this)) {
            append("[!] Izin RUN_COMMAND belum ada. Ketuk preset [ IZIN ] dulu.\n"); return
        }
        output.text = ""
        append("// PERINTAH\n\$ $cmd\n\n")
        append("// OUTPUT\n")
        setRunning(true)
        TermuxBridge.run(this, cmd) { stdout, stderr, exit ->
            runOnUiThread {
                if (stdout.isNotBlank()) append(stdout) else append("(kosong)\n")
                if (stderr.isNotBlank()) append("\n// STDERR\n$stderr\n")
                if (exit != null) append("\n(exit code: $exit)\n")
                if (stdout.isNotBlank()) {
                    append("\n// ANALISA\n")
                    append(TermuxBridge.analyze(cmd, stdout))
                }
                setRunning(false)
                append("\n[ selesai ]\n")
            }
        }
    }
}
