package com.borneotech.cyberlauncher

import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ToolsActivity : AppCompatActivity() {

    private class Def(
        val name: String,
        val cat: String,
        val hint: String,
        val examples: List<String> = emptyList(),
        val run: (ToolBox, String) -> Unit
    )

    private class TPreset(
        val name: String,
        val template: String? = null,
        val hint: String = "",
        val action: ((ToolsActivity) -> Unit)? = null
    )

    private val defs = listOf(
        Def("INFO", "NET", "Info jaringan aktif (IP, gateway, DNS, WiFi). Tanpa input.") { t, _ -> t.netInfo() },
        Def("PING", "NET", "Host/IP yang mau dites.", listOf("8.8.8.8", "google.com")) { t, i -> t.ping(i) },
        Def("TRACE", "NET", "Traceroute ke suatu host.", listOf("google.com", "8.8.8.8")) { t, i -> t.traceroute(i) },
        Def("DNS", "NET", "Lookup alamat IP dari domain.", listOf("google.com", "github.com")) { t, i -> t.dns(i) },
        Def("PORTS", "NET", "host [port]. Hanya perangkat sendiri!", listOf("192.168.1.1 1-1024", "192.168.1.1 22,80,443")) { t, i -> t.portScan(i) },
        Def("LAN", "NET", "Cari perangkat aktif di WiFi /24. Tanpa input. Hanya jaringan sendiri!") { t, _ -> t.lanScan() },
        Def("SUBNET", "NET", "Kalkulator subnet.", listOf("192.168.1.10/24")) { t, i -> t.subnet(i) },
        Def("WHOIS", "NET", "Cek data pendaftaran domain.", listOf("google.com")) { t, i -> t.whois(i) },
        Def("HTTP", "NET", "Lihat header + cek header keamanan situs.", listOf("google.com", "https://google.com")) { t, i -> t.httpHeaders(i) },
        Def("SSL", "NET", "Cek sertifikat TLS situs.", listOf("github.com")) { t, i -> t.sslCheck(i) },
        Def("SPEEDTEST", "NET", "Tes kecepatan unduh. Tanpa input.") { t, _ -> t.speedtest() },
        Def("WIFISCAN", "NET", "Pindai WiFi sekitar + keamanan & rekomendasi channel. Tanpa input, butuh izin lokasi sekali.") { t, _ -> t.wifiScan(this) },
        Def("WIFIINFO", "NET", "Detail WiFi yang lagi terhubung (sinyal, kecepatan, keamanan). Tanpa input.") { t, _ -> t.wifiInfo(this) },
        Def("WIFIMON", "NET", "Monitor sinyal WiFi real-time, buat survei lokasi. Tanpa input, STOP untuk berhenti.") { t, _ -> t.wifiMonitor(this) },
        Def("GEOIP", "NET", "Lokasi geografis dari IP/domain.", listOf("8.8.8.8")) { t, i -> t.geoip(i) },
        Def("WOL", "NET", "Wake-on-LAN, kirim sinyal bangun ke MAC address.", listOf("AA:BB:CC:DD:EE:FF")) { t, i -> t.wol(i) },
        Def("PINGLOOP", "NET", "Ping terus-menerus sampai STOP ditekan.", listOf("8.8.8.8")) { t, i -> t.pingLoop(i) },

        Def("WAF", "SEC", "Deteksi CDN/WAF (Cloudflare, dll) dari header.", listOf("example.com")) { t, i -> t.wafDetect(i) },
        Def("SPF/DMARC", "SEC", "Audit keamanan email domain.", listOf("gmail.com", "example.com")) { t, i -> t.emailSecurity(i) },
        Def("SUBS", "SEC", "Cari subdomain lewat log sertifikat publik.", listOf("example.com")) { t, i -> t.subdomains(i) },
        Def("COOKIE", "SEC", "Cek flag keamanan cookie situs.", listOf("example.com")) { t, i -> t.cookieCheck(i) },
        Def("SEC.TXT", "SEC", "Ambil security.txt & robots.txt.", listOf("google.com")) { t, i -> t.secAndRobots(i) },
        Def("CVE", "SEC", "Cari kerentanan publik dari nama software.", listOf("wordpress 6.0", "openssl")) { t, i -> t.cveSearch(i) },
        Def("HASH", "SEC", "Teks -> MD5/SHA1/SHA256/SHA512.", listOf("hello world")) { t, i -> t.hash(i) },
        Def("ENCODE", "SEC", "Teks -> Base64, URL, Hex.", listOf("hello world")) { t, i -> t.encode(i) },
        Def("DECODE", "SEC", "Tempel string Base64 / URL / Hex.", listOf("aGVsbG8gd29ybGQ=")) { t, i -> t.decode(i) },
        Def("PASSGEN", "SEC", "Panjang password (8-64).", listOf("16", "24")) { t, i -> t.passGen(i) },
        Def("PASSCHK", "SEC", "Cek kekuatan password (dihitung lokal).", listOf("Passw0rd!123")) { t, i -> t.passCheck(i) },
        Def("PWNED", "SEC", "Cek password pernah bocor (aman, k-anonymity).", listOf("123456")) { t, i -> t.pwned(i) },
        Def("JWT", "SEC", "Tempel token JWT untuk di-decode.", listOf("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")) { t, i -> t.jwt(i) },
        Def("APPAUDIT", "SEC", "Audit izin sensitif app terpasang. Tanpa input.") { t, _ -> t.appAudit() }
    )

    private val termPresets = listOf(
        TPreset("CEK", hint = "Cek status setup Termux, langkah demi langkah") { it.checkTermux() },
        TPreset("1.BUKA", hint = "Langkah 1: buka Termux sekali, biarkan jalan di background") { TermuxBridge.openTermux(it) },
        TPreset("2.IZIN", hint = "Langkah 2: izinkan RUN_COMMAND") { it.askTermuxPermission() },
        TPreset("3.OVERLAY", hint = "Langkah 3: aktifkan 'Tampil di atas aplikasi lain' untuk Termux") { TermuxBridge.openOverlaySettings(it) },
        TPreset("4.BATERAI", hint = "Langkah 4: di halaman Termux, pilih Baterai -> Tanpa batasan") { TermuxBridge.openBatterySettings(it) },
        TPreset("SETUP", "pkg update -y && pkg upgrade -y && pkg install -y nmap nikto whatweb", "Install tool: nmap, nikto, whatweb"),
        TPreset("NMAP", "nmap -sV -T4 ", "Scan versi service. Tambahkan target di belakang"),
        TPreset("NMAP-FULL", "nmap -p- -T4 ", "Scan semua 65535 port. Lambat, tambahkan target"),
        TPreset("NIKTO", "nikto -h ", "Scan kerentanan web server. Tambahkan target"),
        TPreset("WHATWEB", "whatweb ", "Deteksi teknologi website. Tambahkan target"),
        TPreset("DIG", "dig ", "DNS lookup lengkap. Tambahkan domain"),
        TPreset("TRACE", "traceroute ", "Jejak rute paket. Tambahkan target"),
        TPreset("TCPDUMP", "tcpdump -i any -c 30", "Tangkap 30 paket jaringan (butuh root untuk hasil penuh)"),
        TPreset("MTR", "pkg install -y mtr && mtr -rw -c 20 ", "Traceroute akurat dgn persentase loss. Tambahkan target"),
        TPreset("SSLSCAN", "pkg install -y sslscan && sslscan ", "Audit cipher TLS lengkap. Tambahkan target:port"),
        TPreset("DIRB", "pkg install -y dirb && dirb https://", "Cari direktori/file tersembunyi di web. HANYA situs sendiri!")
    )

    private val green = 0xFF00FF9C.toInt()
    private val cyan = 0xFF00E5FF.toInt()
    private val red = 0xFFFF3B3B.toInt()

    private lateinit var chips: LinearLayout
    private lateinit var examplesRow: LinearLayout
    private lateinit var usage: TextView
    private lateinit var input: EditText
    private lateinit var output: TextView
    private lateinit var scroll: ScrollView
    private lateinit var btnRun: TextView
    private lateinit var tabNet: TextView
    private lateinit var tabSec: TextView
    private lateinit var tabTerm: TextView

    private var currentDef: Def? = null
    private var category = "NET"
    private var box: ToolBox? = null
    private var running = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tools)

        chips = findViewById(R.id.chips)
        examplesRow = findViewById(R.id.examples)
        usage = findViewById(R.id.usage)
        input = findViewById(R.id.input)
        output = findViewById(R.id.output)
        scroll = findViewById(R.id.scroll)
        btnRun = findViewById(R.id.btnRun)
        tabNet = findViewById(R.id.tabNet)
        tabSec = findViewById(R.id.tabSec)
        tabTerm = findViewById(R.id.tabTerm)

        tabNet.setOnClickListener { showCat("NET") }
        tabSec.setOnClickListener { showCat("SEC") }
        tabTerm.setOnClickListener { showCat("TERM") }
        btnRun.setOnClickListener { if (category == "TERM") runTermux() else runLocal() }
        findViewById<View>(R.id.btnClear).setOnClickListener { output.text = "" }
        input.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_GO) { if (category == "TERM") runTermux() else runLocal() }
            true
        }

        showCat(intent.getStringExtra("cat") ?: "NET")
    }

    override fun onDestroy() {
        super.onDestroy()
        box?.stop()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        val ok = results.isNotEmpty() && results[0] == PackageManager.PERMISSION_GRANTED
        when (code) {
            42 -> append(if (ok) "[ OK ] Izin RUN_COMMAND diberikan.\n" else "[!] Izin RUN_COMMAND ditolak.\n")
            91 -> append(if (ok) "[ OK ] Izin lokasi diberikan, jalankan WIFISCAN sekali lagi.\n" else "[!] Izin lokasi ditolak, WIFISCAN tidak bisa jalan.\n")
        }
    }

    private fun setColors(sel: String) {
        tabNet.setTextColor(if (sel == "NET") green else cyan)
        tabSec.setTextColor(if (sel == "SEC") green else cyan)
        tabTerm.setTextColor(if (sel == "TERM") green else cyan)
    }

    private fun showCat(cat: String) {
        category = cat
        setColors(cat)
        if (cat == "TERM") {
            buildChipGrid(termPresets.map { it.name }, perRow = 3) { name ->
                val p = termPresets.first { it.name == name }
                if (p.action != null) {
                    examplesRow.removeAllViews()
                    p.action.invoke(this)
                } else {
                    usage.text = "[ ${p.name} ] ${p.hint}"
                    val tpl = p.template ?: ""
                    // Target uji resmi & legal dari proyek Nmap, aman dipakai latihan scan/nikto/dll.
                    // Langsung diisi otomatis supaya preset siap RUN tanpa ketukan tambahan.
                    val needsTarget = tpl.endsWith(" ") || tpl.endsWith("https://")
                    val defaultTarget = "scanme.nmap.org"
                    input.setText(if (needsTarget) tpl + defaultTarget else tpl)
                    input.setSelection(input.text.length)
                    showExamples(if (needsTarget) listOf(defaultTarget) else emptyList()) { v ->
                        input.setText(tpl + v)
                        input.setSelection(input.text.length)
                    }
                }
            }
            usage.text = "[ TERMUX ] Jalankan perintah langsung di Termux. Pilih preset atau ketik manual, lalu RUN."
            input.hint = "root@borneo:~$ perintah bebas..."
            input.setText("")
            output.text = ""
            examplesRow.removeAllViews()
            checkTermux()
            return
        }
        val list = defs.filter { it.cat == cat }
        buildChipGrid(list.map { it.name }, perRow = if (cat == "SEC") 2 else 3) { name ->
            select(list.first { it.name == name })
        }
        select(list.first())
        ((chips.getChildAt(0) as? LinearLayout)?.getChildAt(0) as? TextView)?.setTextColor(green)
    }

    /** Susun chip jadi beberapa baris (perRow kolom) supaya tidak jadi satu baris panjang geser-geser. */
    private fun buildChipGrid(names: List<String>, perRow: Int, onClick: (String) -> Unit) {
        chips.removeAllViews()
        names.chunked(perRow).forEach { rowNames ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            rowNames.forEach { n -> row.addView(makeChip(n, onClick), rowChipParams()) }
            chips.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        }
    }

    private fun rowChipParams(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        lp.setMargins(0, 0, 8, 8)
        return lp
    }

    private fun makeChip(name: String, onClick: (String) -> Unit): TextView = TextView(this).apply {
        text = name
        textSize = 11f
        typeface = Typeface.MONOSPACE
        gravity = android.view.Gravity.CENTER
        maxLines = 1
        ellipsize = android.text.TextUtils.TruncateAt.END
        setPadding(10, 14, 10, 14)
        setBackgroundResource(R.drawable.panel_border)
        setTextColor(cyan)
        setOnClickListener {
            onClick(name)
            for (r in 0 until chips.childCount) {
                val row = chips.getChildAt(r) as LinearLayout
                for (i in 0 until row.childCount) (row.getChildAt(i) as TextView).setTextColor(cyan)
            }
            setTextColor(green)
        }
    }

    private fun select(d: Def) {
        currentDef = d
        usage.text = "[ ${d.name} ] ${d.hint}"
        input.hint = "root@borneo:~$ ${d.name.lowercase()}"
        input.setText("")
        showExamples(d.examples) { v -> input.setText(v); input.setSelection(input.text.length) }
    }

    /** Tombol contoh isian di bawah petunjuk, tap langsung isi kolom input tanpa perlu ketik. */
    private fun showExamples(values: List<String>, onPick: (String) -> Unit) {
        examplesRow.removeAllViews()
        if (values.isEmpty()) return
        values.forEach { v ->
            val chip = TextView(this).apply {
                text = "➜ $v"
                textSize = 11f
                typeface = Typeface.MONOSPACE
                setPadding(20, 10, 20, 10)
                setBackgroundResource(R.drawable.panel_border)
                setTextColor(cyan)
                setOnClickListener { onPick(v) }
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, 0, 8, 0)
            examplesRow.addView(chip, lp)
        }
    }

    private fun append(s: String) {
        output.append(s)
        if (output.length() > 80000) output.text = output.text.takeLast(60000)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setRunning(on: Boolean) {
        running = on
        btnRun.text = if (on) "[ STOP ]" else "[ RUN ]"
        btnRun.setTextColor(if (on) red else green)
    }

    private fun runLocal() {
        if (running) { box?.stop(); return }
        val d = currentDef ?: return
        output.text = ""
        val tb = ToolBox(this) { s -> runOnUiThread { append(s) } }
        box = tb
        setRunning(true)
        val text = input.text.toString()
        Thread {
            try {
                d.run(tb, text)
            } catch (e: Exception) {
                if (!tb.cancelled) tb.out("[!] ${e.javaClass.simpleName}: ${e.message}\n")
            }
            runOnUiThread { setRunning(false); append("\n[ selesai ]\n") }
        }.start()
    }

    // ---------- TERMUX ----------
    fun checkTermux() {
        val inst = TermuxBridge.isInstalled(this)
        val perm = TermuxBridge.hasPermission(this)
        append("// PANDUAN SETUP TERMUX (sekali saja, urut dari atas)\n\n")
        append("${if (inst) "[v]" else "[ ]"} 1. Pasang Termux dari F-Droid/GitHub (BUKAN Play Store)\n")
        append("${if (perm) "[v]" else "[ ]"} 2. Izin RUN_COMMAND aktif\n")
        append("[ ] 3. Izin 'Tampil di atas aplikasi lain' aktif untuk Termux\n")
        append("[ ] 4. Baterai Termux disetel 'Tanpa batasan'\n")
        append("[ ] 5. Di Termux, sekali jalankan perintah ini:\n")
        append("       echo 'allow-external-apps=true' >> ~/.termux/termux.properties\n")
        append("       termux-reload-settings\n\n")
        append("Langkah 3 & 4 TIDAK bisa dicek otomatis oleh Android, jadi tetap diperiksa manual\n")
        append("walau checklist di atas sudah centang semua.\n\n")
        when {
            !inst -> append("-> Mulai dari langkah 1: ketuk [ 1.BUKA ] untuk pasang Termux.\n")
            !perm -> append("-> Lanjut langkah 2: ketuk [ 2.IZIN ].\n")
            else -> {
                append("-> Langkah 1 & 2 beres. Pastikan langkah 3, 4, 5 juga sudah, lalu coba jalankan\n")
                append("   perintah (misal WHATWEB) sekali. Kalau outputnya tetap kosong, itu tandanya\n")
                append("   langkah 3/4/5 belum lengkap, bukan masalah di launcher ini.\n")
            }
        }
    }

    fun askTermuxPermission() {
        if (!TermuxBridge.isInstalled(this)) {
            append("[!] Termux belum terpasang. Membuka halaman unduh...\n")
            TermuxBridge.openInstallPage(this)
            return
        }
        if (TermuxBridge.hasPermission(this)) {
            append("[ OK ] Izin sudah ada.\n")
            return
        }
        TermuxBridge.requestPermission(this, 42)
    }

    private fun runTermux() {
        if (running) { setRunning(false); return }
        val cmd = input.text.toString().trim()
        if (cmd.isEmpty()) { append("[!] Isi perintah dulu\n"); return }
        if (!TermuxBridge.isInstalled(this)) {
            append("[!] Termux belum terpasang. Ketuk preset [ BUKA ] atau install dari F-Droid.\n"); return
        }
        if (!TermuxBridge.hasPermission(this)) {
            append("[!] Izin RUN_COMMAND belum ada. Ketuk preset [ IZIN ] dulu.\n"); return
        }
        output.text = ""
        append("// PERINTAH\n\$ $cmd\n\n")
        append("// OUTPUT\n")
        setRunning(true)
        TermuxBridge.run(this, cmd) { stdout, stderr, exit ->
            runOnUiThread {
                if (stdout.isNotBlank()) append(stdout) else append("(kosong)\n")
                if (stderr.isNotBlank()) append("\n// STDERR\n$stderr\n")
                if (exit != null) append("\n(exit code: $exit)\n")
                if (stdout.isNotBlank()) {
                    append("\n// ANALISA\n")
                    append(TermuxBridge.analyze(cmd, stdout))
                }
                setRunning(false)
                append("\n[ selesai ]\n")
            }
        }
    }
}
