plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.borneotech.cyberlauncher"
    compileSdk = 34

    signingConfigs {
        create("cyber") {
            storeFile = file("cyberlauncher.keystore")
            storePassword = "cyberlauncher123"
            keyAlias = "cyberlauncher"
            keyPassword = "cyberlauncher123"
        }
    }

    defaultConfig {
        applicationId = "com.borneotech.cyberlauncher"
        minSdk = 29
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("cyber")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
}
